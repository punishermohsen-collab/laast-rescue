# گزارش تحقیق فنی — مرحلهٔ ۱۶ «آخرین نجات»

## جمع‌بندی تصمیم

**مسیر اصلی انتخاب‌شده: Godot 4.6 پایدار + قالب‌های Export هم‌نسخه + Android SDK + JDK 17؛ برای اجرای تکرارپذیر، گردش‌کار GitHub Actions اضافه شده است.** این مسیر کد سه‌بعدی فعلی را حفظ می‌کند و در صورت قرارگرفتن پروژه در یک مخزن GitHub، می‌تواند APK آزمایشی را به‌عنوان Artifact خروجی بسازد. این فایل‌ها فقط گردش‌کار را آماده می‌کنند؛ چون گردش‌کار در GitHub اجرا نشده، هنوز APK واقعی تحویل‌شده یا تأییدشده‌ای وجود ندارد.

## مقایسهٔ مسیرها بر اساس مستندات

| مسیر | حفظ پروژهٔ سه‌بعدی Godot | نیاز اصلی | نتیجه و محدودیت |
|---|---|---|---|
| Godot Desktop + Export Android | کامل‌ترین بازاستفاده | Godot، Export Templates هم‌نسخه، JDK و Android SDK | **مسیر مرجع**؛ امکان بررسی خطاها و اجرای صحنه قبل از خروجی |
| GitHub Actions + Godot CLI | بله | مخزن GitHub، فعال‌کردن Actions و دسترسی شبکه در runner | **مسیر جایگزین ساخت**؛ فایل APK به‌صورت Artifact قابل دریافت می‌شود، ولی باید اولین اجرا واقعاً سبز شود |
| Godot Android Editor | ویرایش پروژه روی گوشی | نصب برنامه و فضای کافی | برای ویرایش/آزمایش مفید است؛ مستندات Godot 4.3 صریحاً می‌گوید نسخهٔ آن زمان خروجی APK را مستقیماً نمی‌ساخت، پس فعلاً راه مطمئن ساخت APK فرض نمی‌شود |
| Android Studio + WebView | خیر؛ فقط نسخهٔ مرورگری دوبعدی | Android SDK، Gradle و Java | fallback سریع برای نسخهٔ دوبعدی، نه جایگزین APK سه‌بعدی Godot |
| Unity | نیازمند بازسازی | Unity Editor و Android Build Support شامل SDK/NDK/JDK | گزینهٔ مهاجرت فقط در صورت وجود مانع مشخص در Godot؛ تبدیل خودکار پروژه تضمین‌شده نیست |
| Unreal Engine | نیازمند بازسازی عمده | Unreal و زنجیرهٔ ساخت Android | برای این نمونهٔ اولیه، هزینهٔ مهاجرت و ساخت بالاتر؛ فعلاً انتخاب اول نیست |

## مواردی که مستندات معتبر تأیید می‌کنند

1. مستندات رسمی Godot 4.6 برای Export اندروید، نصب JDK 17 و Android SDK و قالب‌های خروجی را توضیح می‌دهد؛ برای سازگاری باید قالب Export با نسخهٔ خود موتور یکی باشد.
2. مستندات Android Developers برای Godot توضیح می‌دهد که Godot می‌تواند APK برای آزمایش محلی و AAB برای انتشار فروشگاهی بسازد؛ APK آزمایشی و AAB فروشگاهی یک هدف واحد نیستند.
3. مستندات Godot برای خط فرمان می‌گوید Export به یک preset نام‌گذاری‌شده نیاز دارد؛ به همین دلیل preset «Android» به پروژه اضافه شده است.
4. مستندات Godot دربارهٔ Android Editor هشدار می‌دهد که محدودیت‌های نسخه/دورهٔ مستندشده باید بررسی شوند؛ بنابراین صرف نصب ویرایشگر موبایل را معادل تولید APK نهایی نمی‌گیریم.
5. مستندات Unity نشان می‌دهد خروجی اندروید آن هم به Android Build Support، SDK، NDK و JDK نیاز دارد؛ عوض‌کردن موتور به‌تنهایی مشکل زنجیرهٔ ساخت را حذف نمی‌کند.

## فایل‌های تازه در این مرحله

- `.github/workflows/android-apk.yml`: گردش‌کار دستی و خودکار برای نصب زنجیرهٔ ساخت، دانلود Godot 4.6 و قالب‌های متناظر، import پروژه، Export APK آزمایشی و آپلود Artifact.
- `LastRescue_Godot_Project/export_presets.cfg`: preset اندروید، نام بسته `com.lastrescue.game`، حالت افقی و معماری ARM64 برای APK آزمایشی.
- گرافیک: حلقه‌های آیینی قرمز در نسخهٔ سه‌بعدی اکنون با ریتم کم‌هزینه روشن و کم‌نور می‌شوند؛ نسخهٔ مرورگری نیز ذرات آیینی شناور دارد.
- داستان: دیالوگ کوتاه پس از نجات دختر به نسخهٔ مرورگری و Godot اضافه شد.

## نکات امنیتی و انتشار

- APK تولیدشده توسط workflow یک **debug build برای آزمایش** است؛ برای انتشار عمومی باید keystore خصوصی مدیریت‌شده و امضای release به‌طور جداگانه پیکربندی شود. کلید و رمز را در فایل‌های پروژه یا مخزن عمومی قرار ندهید.
- Workflow برای Godot 4.6 pin شده و قالب‌های همان نسخه را دانلود می‌کند؛ به‌روزرسانی موتور باید همراه با بازبینی SDK/NDK و قالب‌ها انجام شود.
- اجرای موفق workflow، صحت ساخت را تأیید می‌کند، نه عملکرد روان روی همهٔ گوشی‌ها. پس از ساخت، APK باید روی دستگاه واقعی نصب و کنترل لمسی، جهت افقی، نرخ فریم، صدا و چرخهٔ توقف/بازگشت آزمایش شود.
- این محیط به شبکهٔ دانلود GitHub و خود موتور Godot دسترسی اجرایی نداشت؛ بنابراین ساخت APK، اجرای GDScript در موتور واقعی و نصب روی گوشی در این مرحله **تأیید نشده‌اند**.

## منابع رسمی

- Godot 4.6 — Exporting for Android: https://docs.godotengine.org/en/4.6/tutorials/export/exporting_for_android.html
- Godot 4.3 — Exporting projects / command line: https://docs.godotengine.org/en/4.3/tutorials/export/exporting_projects.html
- Android Developers — Export Godot projects to Android: https://developer.android.com/games/engines/godot/godot-export
- Godot 4.3 — Using the Android editor (محدودیت‌های آن نسخه): https://docs.godotengine.org/en/4.3/tutorials/editor/using_the_android_editor.html
- Unity 6 — Android environment setup: https://docs.unity.com/en-us/engine/7000.0/manual/platform-specific/android/getting-started/sdksetup
- GitHub Actions — Uploading build artifacts: https://docs.github.com/en/actions/using-workflows/storing-workflow-data-as-artifacts
