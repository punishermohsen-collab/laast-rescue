# تحقیق مسیر جایگزین ساخت — مرحلهٔ ۲۷

## تصمیم
- مسیر اصلی سه‌بعدی: GitHub Actions با Godot 4.6 CLI، قالب خروجی هم‌نسخه، import headless، اجرای صحنه headless و export APK.
- مسیر پشتیبان: Android WebView + Gradle؛ فقط نسخهٔ مرورگری را بسته‌بندی می‌کند و جایگزین بازی سه‌بعدی نیست.
- مسیر CI جایگزین: `.gitlab-ci.yml`؛ دوبار تست QA را اجرا می‌کند و job جداگانه برای ساخت APK پشتیبان دارد. باید پس از واردکردن پروژه به مخزن GitLab و اجرای pipeline تأیید شود؛ فایل تنظیمات به‌تنهایی اثبات ساخت موفق نیست.
- مسیر دستگاهی: Godot Android Editor و GABE برای زمانی که ابزارها روی دستگاه واقعی نصب و سازگار باشند؛ عملکرد/ساخت باید جداگانه تست شود.

## مقایسه
| مسیر | خروجی | وابستگی/ریسک |
|---|---|---|
| Godot CLI + GitHub Actions | APK سه‌بعدی اصلی | نیازمند شبکه و runner؛ تا اجرای موفق artifact تأیید نشده |
| GitLab CI + Android build image | APK پشتیبان WebView | image و SDK باید در runner در دسترس باشند؛ pipeline هنوز اجرا نشده |
| ساخت محلی با Godot + Android SDK | APK سه‌بعدی | نیازمند Godot، export templates هم‌نسخه، JDK و Android SDK |
| WebView/Gradle | APK بازی HTML | گرافیک و منطق نسخهٔ مرورگری، نه صحنهٔ سه‌بعدی |
| Unity/Unreal | نیاز به بازسازی | انتقال خودکار پروژهٔ Godot تضمین‌شده نیست؛ فقط با مانع فنی واقعی بررسی شود |

## معیار پذیرش
1. QA دوبار پشت سر هم اجرا شود و هر دو خروجی موفق باشند.
2. HTML مرورگر و WebView بایت‌به‌بایت یکسان باشند.
3. ZIP پروژه سالم باشد.
4. برای ادعای APK آماده: CI واقعاً اجرا شود، artifact دانلود شود، ساختار APK بررسی و روی گوشی نصب/اجرا شود.

## منابع
- Godot Android export: https://docs.godotengine.org/en/stable/tutorials/export/exporting_for_android.html
- Godot Android editor: https://docs.godotengine.org/en/4.6/tutorials/editor/using_the_android_editor.html
- Android Developers, Godot export: https://developer.android.com/games/engines/godot/godot-export
- Godot CI examples: https://github.com/abarichello/godot-ci
- Godot Android Build Environment announcement: https://godotengine.org/article/gabe-stable-release/

## وضعیت شفاف
در این محیط، `godot` و `gradle` نصب نیستند؛ پس اجرای واقعی Godot و تولید/نصب APK محلی تأیید نشده. CI جایگزین اضافه شده ولی هنوز در GitLab اجرا نشده.
