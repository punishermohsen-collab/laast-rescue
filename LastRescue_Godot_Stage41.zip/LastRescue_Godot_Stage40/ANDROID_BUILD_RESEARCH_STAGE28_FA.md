# مسیرهای ساخت و جایگزین — مرحلهٔ ۲۸

1. مسیر اصلی: GitHub Actions، Godot 4.6 pinned + export templates هم‌نسخه، import/headless smoke test و سپس export APK سه‌بعدی.
2. مسیر پشتیبان مستقل: Gradle برای بسته‌بندی Browser/WebView؛ این APK جایگزین بازی سه‌بعدی Godot نیست.
3. مسیر CI دوم: GitLab CI موجود در بسته؛ تا اجرای روی runner واقعی، موفقیت آن تأیید نشده است.
4. مسیر محلی/موبایل: Godot Android Editor/GABE و Android SDK سازگار؛ لازم است export templates هم‌نسخه نصب و APK روی دستگاه واقعی آزمایش شود.
5. موتور دیگر مانند Unity/Unreal فقط در صورت خطای مسدودکننده و پس از ارزیابی هزینهٔ بازسازی؛ تبدیل خودکار پروژهٔ Godot نیست.

در این محیط، نبودن Godot/Gradle محلی یعنی ساخت واقعی APK قابل تأیید نیست. خروجی pipeline باید شامل log خطا، APK قابل نصب و آزمون نصب/اجرا باشد.
