# بررسی مسیرهای ساخت APK — مرحله ۲۹

## مسیر اصلی: Godot 3D با CI
- workflow موجود `.github/workflows/android-apk.yml` پروژه Godot را با Godot 4.6، export templates و Android SDK می‌سازد و پیش از export یک اجرای headless دارد.
- منطق درست: اگر import یا اجرای headless شکست خورد، خروجی APK سه‌بعدی نباید به‌عنوان artifact موفق منتشر شود.
- منبع رسمی export: https://docs.godotengine.org/en/4.6/tutorials/export/exporting_for_android.html

## مسیر جایگزین A: ساخت روی خود دستگاه اندروید
- در تاریخ ۲ ژوئن ۲۰۲۶، Godot اعلام کرده GABE پایدار شده؛ GABE همراه Godot Android Editor محیط Gradle را فراهم می‌کند و اجازهٔ خروجی APK/AAB مستقیم روی دستگاه را می‌دهد.
- این روش نیازمند نصب Godot Android Editor و برنامهٔ GABE، دانلود وابستگی‌ها و دادن دسترسی به پوشهٔ پروژه است؛ این کار از این محیط به‌صورت واقعی قابل اجرا نیست.
- منبع رسمی: https://godotengine.org/article/gabe-stable-release/
- راهنمای رسمی: https://docs.godotengine.org/en/4.6/tutorials/export/android_gradle_build.html

## مسیر جایگزین B: WebView/Gradle
- پروژهٔ `Android_WebView_Wrapper` نسخهٔ HTML را در برنامهٔ Android بسته‌بندی می‌کند. این fallback مستقل است و جایگزین بازی سه‌بعدی Godot محسوب نمی‌شود.
- تست Node/VM رفتار جاوااسکریپت را شبیه‌سازی می‌کند؛ نه اجرای واقعی روی مرورگر اندروید و نه نصب APK.

## وضعیت این مرحله
- تست‌های محلی پروژه اجراشدنی‌اند؛ Godot و Gradle در این محیط نصب نیستند.
- CI واقعی GitHub/GitLab هنوز اجرا نشده و APK واقعی ساخته/نصب نشده است؛ بنابراین نباید ساخت APK را تأییدشده اعلام کرد.
- پیشنهاد مسیر اجرایی بعدی: push کردن ZIP به یک مخزن GitHub و اجرای workflow، سپس بررسی log کامل و دانلود artifact؛ در صورت شکست، خطای مشخص را رفع و مسیر GABE روی دستگاه را جداگانه آزمایش کنیم.
