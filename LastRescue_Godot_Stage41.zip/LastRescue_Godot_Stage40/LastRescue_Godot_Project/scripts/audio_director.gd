extends Node

# Stage 19: voice acting and sound hooks. Audio assets are intentionally not fabricated.
# Put licensed/generated WAV or OGG files at the paths listed below.
const VOICE_FILES := {
    "intro_girl_01": "res://audio/voices/intro_girl_01.ogg",
    "intro_masked_01": "res://audio/voices/intro_masked_01.ogg",
    "intro_hero_01": "res://audio/voices/intro_hero_01.ogg",
    "rescue_girl_01": "res://audio/voices/rescue_girl_01.ogg",
    "rescue_hero_01": "res://audio/voices/rescue_hero_01.ogg",
    "rescue_girl_02": "res://audio/voices/rescue_girl_02.ogg",
    "masked_tease_01": "res://audio/voices/masked_tease_01.ogg",
    "stage2_girl_01": "res://audio/voices/stage2_girl_01.ogg",
    "stage2_hero_01": "res://audio/voices/stage2_hero_01.ogg",
    "stage2_girl_02": "res://audio/voices/stage2_girl_02.ogg",
    "radio_stage2_01": "res://audio/voices/radio_stage2_01.ogg",
    "stage3_girl_01": "res://audio/voices/stage3_girl_01.ogg",
    "stage3_hero_01": "res://audio/voices/stage3_hero_01.ogg",
    "radio_stage3_01": "res://audio/voices/radio_stage3_01.ogg",
    "stage7_girl_01": "res://audio/voices/stage7_girl_01.ogg",
    "stage7_hero_01": "res://audio/voices/stage7_hero_01.ogg",
    "stage7_girl_02": "res://audio/voices/stage7_girl_02.ogg",
    "stage7_masked_01": "res://audio/voices/stage7_masked_01.ogg",
    "stage8_hero_01": "res://audio/voices/stage8_hero_01.ogg",
    "stage8_girl_01": "res://audio/voices/stage8_girl_01.ogg",
    "stage8_masked_01": "res://audio/voices/stage8_masked_01.ogg",
    "radio_stage8_01": "res://audio/voices/radio_stage8_01.ogg",
    "stage9_hero_01": "res://audio/voices/stage9_hero_01.ogg",
    "stage9_girl_01": "res://audio/voices/stage9_girl_01.ogg",
    "stage9_hero_02": "res://audio/voices/stage9_hero_02.ogg",
    "stage9_masked_01": "res://audio/voices/stage9_masked_01.ogg",
    "stage10_girl_01": "res://audio/voices/stage10_girl_01.ogg",
    "stage10_hero_01": "res://audio/voices/stage10_hero_01.ogg",
    "stage10_masked_01": "res://audio/voices/stage10_masked_01.ogg",
    "stage10_girl_02": "res://audio/voices/stage10_girl_02.ogg",
    "stage11_girl_01": "res://audio/voices/stage11_girl_01.ogg",
    "stage11_hero_01": "res://audio/voices/stage11_hero_01.ogg",
    "stage11_masked_01": "res://audio/voices/stage11_masked_01.ogg",
    "stage11_girl_02": "res://audio/voices/stage11_girl_02.ogg",
    "stage12_radio_01": "res://audio/voices/stage12_radio_01.ogg",
    "stage12_hero_01": "res://audio/voices/stage12_hero_01.ogg",
    "stage12_girl_01": "res://audio/voices/stage12_girl_01.ogg",
    "stage12_masked_01": "res://audio/voices/stage12_masked_01.ogg",
    "transition_hero_01": "res://audio/voices/transition_hero_01.ogg",
    "transition_girl_01": "res://audio/voices/transition_girl_01.ogg",
    "stage9_hero_01_en": "res://audio/voices/stage9_hero_01_en.ogg",
    "stage9_girl_01_en": "res://audio/voices/stage9_girl_01_en.ogg",
    "stage9_hero_02_en": "res://audio/voices/stage9_hero_02_en.ogg",
    "stage9_masked_01_en": "res://audio/voices/stage9_masked_01_en.ogg",
    "stage10_girl_01_en": "res://audio/voices/stage10_girl_01_en.ogg",
    "stage10_hero_01_en": "res://audio/voices/stage10_hero_01_en.ogg",
    "stage10_masked_01_en": "res://audio/voices/stage10_masked_01_en.ogg",
    "stage10_girl_02_en": "res://audio/voices/stage10_girl_02_en.ogg",
    "stage11_girl_01_en": "res://audio/voices/stage11_girl_01_en.ogg",
    "stage11_hero_01_en": "res://audio/voices/stage11_hero_01_en.ogg",
    "stage11_masked_01_en": "res://audio/voices/stage11_masked_01_en.ogg",
    "stage11_girl_02_en": "res://audio/voices/stage11_girl_02_en.ogg",
    "stage12_radio_01_en": "res://audio/voices/stage12_radio_01_en.ogg",
    "stage12_hero_01_en": "res://audio/voices/stage12_hero_01_en.ogg",
    "stage12_girl_01_en": "res://audio/voices/stage12_girl_01_en.ogg",
    "stage12_masked_01_en": "res://audio/voices/stage12_masked_01_en.ogg",
    "transition_masked_01": "res://audio/voices/transition_masked_01.ogg"
}
const SFX_FILES := {
    "axe_swing": "res://audio/sfx/axe_swing.wav",
    "axe_impact": "res://audio/sfx/axe_impact.wav",
    "hero_hurt": "res://audio/sfx/hero_hurt.wav",
    "zombie_attack": "res://audio/sfx/zombie_attack.wav",
    "zombie_death": "res://audio/sfx/zombie_death.wav",
    "brute_roar": "res://audio/sfx/brute_roar.wav"
}
const AMBIENCE_FILES := {
    "cemetery_wind": "res://audio/ambience/cemetery_wind.wav"
}

var voice_player: AudioStreamPlayer
var sfx_player: AudioStreamPlayer
var ambience_player: AudioStreamPlayer
var warned_missing := {}

func _ready() -> void:
    voice_player = AudioStreamPlayer.new()
    voice_player.name = "PersianVoicePlayer"
    voice_player.bus = "Master"
    add_child(voice_player)
    sfx_player = AudioStreamPlayer.new()
    sfx_player.name = "SoundEffectsPlayer"
    add_child(sfx_player)
    ambience_player = AudioStreamPlayer.new()
    ambience_player.name = "CemeteryAmbiencePlayer"
    ambience_player.volume_db = -14.0
    add_child(ambience_player)
    play_ambience("cemetery_wind")

func _load_audio(path: String, asset_id: String) -> AudioStream:
    if not ResourceLoader.exists(path):
        if not warned_missing.has(asset_id):
            warned_missing[asset_id] = true
            push_warning("Audio asset not installed yet: " + path)
        return null
    return load(path) as AudioStream

func play_voice(asset_id: String) -> bool:
    if not VOICE_FILES.has(asset_id):
        push_warning("Unknown voice cue: " + asset_id)
        return false
    var stream := _load_audio(VOICE_FILES[asset_id], asset_id)
    if stream == null:
        return false
    voice_player.stream = stream
    # Tiny per-line variation avoids perfectly identical playback while preserving intelligibility.
    voice_player.pitch_scale = randf_range(0.98, 1.02)
    voice_player.volume_db = randf_range(-0.8, 0.0)
    voice_player.play()
    return true

func play_voice_sequence(asset_ids: Array) -> void:
    for asset_id in asset_ids:
        if play_voice(str(asset_id)):
            await voice_player.finished

func play_sfx(asset_id: String) -> void:
    if not SFX_FILES.has(asset_id):
        return
    var stream := _load_audio(SFX_FILES[asset_id], asset_id)
    if stream == null:
        return
    sfx_player.stream = stream
    sfx_player.play()

func play_ambience(asset_id: String) -> void:
    if not AMBIENCE_FILES.has(asset_id):
        return
    var stream := _load_audio(AMBIENCE_FILES[asset_id], asset_id)
    if stream == null:
        return
    if stream is AudioStreamWAV:
        stream.loop_mode = AudioStreamWAV.LOOP_FORWARD
    ambience_player.stream = stream
    ambience_player.play()
