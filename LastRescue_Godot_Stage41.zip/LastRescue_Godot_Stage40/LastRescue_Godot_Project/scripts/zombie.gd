extends CharacterBody3D

@export var max_health: float = 70.0
@export var move_speed: float = 1.65
@export var attack_damage: float = 6.5
@export var attack_distance: float = 1.45
@export var attack_interval: float = 1.25
@export var notice_distance: float = 22.0
@export var flanking_enabled: bool = true
@export var is_brute: bool = false

var health: float = 70.0
var player: Node3D
var attack_timer: float = 0.0
var gravity: float = 18.0
var body: MeshInstance3D
var original_material: StandardMaterial3D
var stagger_timer: float = 0.0
var is_emerging: bool = true
var left_arm: MeshInstance3D
var right_arm: MeshInstance3D
var left_leg: MeshInstance3D
var right_leg: MeshInstance3D
var anim_clock: float = 0.0
var hurt_flash_timer: float = 0.0
var dying: bool = false
var orbit_sign: float = 1.0
var orbit_clock: float = 1.8
var brute_windup_timer: float = 0.0
var brute_slam_cooldown: float = 0.0
var knockback_velocity: Vector3 = Vector3.ZERO

func _ready() -> void:
    health = max_health
    orbit_sign = -1.0 if randf() < 0.5 else 1.0
    orbit_clock = randf_range(1.4, 2.8)
    add_to_group("zombies")
    _build_zombie()
    # Stage 6: the undead rise from below ground before they start hunting. Stage 40 adds brute slam telegraph.
    var ground_y := position.y
    position.y = ground_y - 2.2
    var rise := create_tween()
    rise.tween_property(self, "position:y", ground_y, 1.45).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)
    rise.finished.connect(func(): is_emerging = false)

func _build_zombie() -> void:
    body = MeshInstance3D.new()
    var mesh := CapsuleMesh.new()
    mesh.radius = 0.42
    mesh.height = 1.75
    body.mesh = mesh
    body.position.y = 0.88
    original_material = StandardMaterial3D.new()
    original_material.albedo_color = Color(0.18, 0.25, 0.16)
    original_material.roughness = 1.0
    body.material_override = original_material
    add_child(body)

    var head := MeshInstance3D.new()
    var head_mesh := SphereMesh.new()
    head_mesh.radius = 0.25
    head_mesh.height = 0.5
    head.mesh = head_mesh
    head.position.y = 1.82
    var head_mat := StandardMaterial3D.new()
    head_mat.albedo_color = Color(0.25, 0.31, 0.2)
    head.material_override = head_mat
    add_child(head)

    # Stage 12: recessed dark mouth and uneven torn-cloth patches break up the smooth silhouette.
    var mouth := MeshInstance3D.new()
    var mouth_mesh := BoxMesh.new()
    mouth_mesh.size = Vector3(0.14, 0.045, 0.035)
    mouth.mesh = mouth_mesh
    mouth.position = Vector3(0.0, 1.70, -0.238)
    var mouth_mat := StandardMaterial3D.new()
    mouth_mat.albedo_color = Color(0.055, 0.018, 0.015)
    mouth_mat.roughness = 1.0
    mouth.material_override = mouth_mat
    add_child(mouth)

    var torn_mat := StandardMaterial3D.new()
    torn_mat.albedo_color = Color(0.07, 0.085, 0.075)
    torn_mat.roughness = 1.0
    for patch_data in [Vector3(-0.16, 1.10, -0.365), Vector3(0.18, 0.72, -0.36), Vector3(-0.12, 0.42, -0.35)]:
        var patch := MeshInstance3D.new()
        var patch_mesh := BoxMesh.new()
        patch_mesh.size = Vector3(0.13, 0.19, 0.025)
        patch.mesh = patch_mesh
        patch.position = patch_data
        patch.rotation.z = randf_range(-0.35, 0.35)
        patch.material_override = torn_mat
        add_child(patch)

    # Sickly emissive eyes make the undead readable in low light without textures.
    var eye_mat := StandardMaterial3D.new()
    eye_mat.albedo_color = Color(0.85, 0.12, 0.055)
    eye_mat.emission_enabled = true
    eye_mat.emission = Color(0.9, 0.055, 0.025)
    eye_mat.emission_energy_multiplier = 1.8
    for side in [-1.0, 1.0]:
        var eye := MeshInstance3D.new()
        var eye_mesh := SphereMesh.new()
        eye_mesh.radius = 0.045
        eye_mesh.height = 0.09
        eye.mesh = eye_mesh
        eye.position = Vector3(side * 0.105, 1.86, -0.205)
        eye.material_override = eye_mat
        add_child(eye)

    # Uneven hanging arms and darker torn-cloth patches add a less toy-like silhouette.
    var arm_mat := StandardMaterial3D.new()
    arm_mat.albedo_color = Color(0.16, 0.21, 0.14)
    arm_mat.roughness = 1.0
    for side in [-1.0, 1.0]:
        var arm := MeshInstance3D.new()
        var arm_mesh := CapsuleMesh.new()
        arm_mesh.radius = 0.105
        arm_mesh.height = 0.78
        arm.mesh = arm_mesh
        arm.position = Vector3(side * 0.48, 0.88, -0.015)
        arm.rotation.z = side * -0.16
        arm.material_override = arm_mat
        add_child(arm)
        if side < 0.0:
            left_arm = arm
        else:
            right_arm = arm

    var leg_mat := StandardMaterial3D.new()
    leg_mat.albedo_color = Color(0.10, 0.13, 0.11)
    leg_mat.roughness = 1.0
    for side in [-1.0, 1.0]:
        var leg := MeshInstance3D.new()
        var leg_mesh := CapsuleMesh.new()
        leg_mesh.radius = 0.13
        leg_mesh.height = 0.72
        leg.mesh = leg_mesh
        leg.position = Vector3(side * 0.19, 0.28, 0.015)
        leg.material_override = leg_mat
        add_child(leg)
        if side < 0.0:
            left_leg = leg
        else:
            right_leg = leg

    var collision := CollisionShape3D.new()
    var shape := CapsuleShape3D.new()
    shape.radius = 0.42
    shape.height = 1.75
    collision.shape = shape
    collision.position.y = 0.88
    add_child(collision)

func _physics_process(delta: float) -> void:
    anim_clock += delta
    if left_arm and right_arm and left_leg and right_leg:
        var moving := Vector2(velocity.x, velocity.z).length() > 0.2 and not is_emerging
        var swing := sin(anim_clock * (7.0 if moving else 2.0)) * (0.42 if moving else 0.08)
        left_arm.rotation.z = -0.16 + swing
        right_arm.rotation.z = 0.16 - swing
        left_leg.rotation.x = swing * 0.55
        right_leg.rotation.x = -swing * 0.55
    if is_emerging:
        velocity = Vector3.ZERO
        return
    attack_timer = maxf(0.0, attack_timer - delta)
    brute_slam_cooldown = maxf(0.0, brute_slam_cooldown - delta)
    stagger_timer = maxf(0.0, stagger_timer - delta)
    hurt_flash_timer = maxf(0.0, hurt_flash_timer - delta)
    if hurt_flash_timer <= 0.0 and body and body.material_override != original_material:
        body.material_override = original_material
    if not is_instance_valid(player):
        var players := get_tree().get_nodes_in_group("player")
        if players.size() > 0:
            player = players[0]
        else:
            return

    var offset: Vector3 = player.global_position - global_position
    offset.y = 0.0
    var distance := offset.length()
    if distance > notice_distance:
        velocity.x = move_toward(velocity.x, 0.0, 8.0 * delta)
        velocity.z = move_toward(velocity.z, 0.0, 8.0 * delta)
    elif stagger_timer > 0.0:
        velocity.x = move_toward(velocity.x, 0.0, 14.0 * delta)
        velocity.z = move_toward(velocity.z, 0.0, 14.0 * delta)
    elif distance > attack_distance and not (is_brute and brute_windup_timer > 0.0):
        var direction := offset.normalized()
        # Stage 39: ordinary undead pressure the hero from changing angles; the brute advances directly.
        if flanking_enabled and distance > attack_distance * 1.7 and distance < 7.0:
            orbit_clock -= delta
            if orbit_clock <= 0.0:
                orbit_sign *= -1.0
                orbit_clock = randf_range(1.4, 2.8)
            var tangent := Vector3(-direction.z, 0.0, direction.x) * orbit_sign
            direction = (direction + tangent * 0.28).normalized()
        velocity.x = direction.x * move_speed
        velocity.z = direction.z * move_speed
        rotation.y = atan2(-direction.x, -direction.z)
    else:
        velocity.x = move_toward(velocity.x, 0.0, 10.0 * delta)
        velocity.z = move_toward(velocity.z, 0.0, 10.0 * delta)
        if is_brute and brute_windup_timer > 0.0:
            brute_windup_timer = maxf(0.0, brute_windup_timer - delta)
            if brute_windup_timer <= 0.0:
                # Stage 40: the brute's slow ground slam is telegraphed; dodge outside its wider radius.
                if offset.length() <= attack_distance * 2.4 and player.has_method("take_damage"):
                    player.take_damage(attack_damage * 1.6)
                if body:
                    body.scale = Vector3.ONE * 1.12
                    var slam_tween := create_tween()
                    slam_tween.tween_property(body, "scale", Vector3.ONE, 0.18)
                brute_slam_cooldown = attack_interval * 1.25
        elif attack_timer <= 0.0:
            if is_brute:
                if brute_slam_cooldown <= 0.0:
                    brute_windup_timer = 0.78
                    brute_slam_cooldown = attack_interval * 1.25
                    if is_instance_valid(get_tree().current_scene) and get_tree().current_scene.has_method("play_sfx"):
                        get_tree().current_scene.play_sfx("brute_roar")
            else:
                attack_timer = attack_interval
                if player.has_method("take_damage"):
                    player.take_damage(attack_damage)

    if not is_on_floor():
        velocity.y -= gravity * delta
    else:
        velocity.y = 0.0
    velocity.x += knockback_velocity.x
    velocity.z += knockback_velocity.z
    knockback_velocity = knockback_velocity.move_toward(Vector3.ZERO, 5.0 * delta)
    move_and_slide()

func take_damage(amount: float) -> void:
    if dying:
        return
    health -= amount
    stagger_timer = 0.28
    var attacker := get_tree().get_first_node_in_group("player")
    if attacker is Node3D:
        var push: Vector3 = global_position - attacker.global_position
        push.y = 0.0
        if push.length() > 0.01:
            knockback_velocity = push.normalized() * (1.15 if not is_brute else 0.45)
    if body:
        hurt_flash_timer = 0.16
        var hurt_mat := StandardMaterial3D.new()
        hurt_mat.albedo_color = Color(0.48, 0.08, 0.06)
        hurt_mat.roughness = 1.0
        body.material_override = hurt_mat
    if health <= 0.0:
        dying = true
        remove_from_group("zombies")
        velocity = Vector3.ZERO
        set_collision_layer(0)
        set_collision_mask(0)
        var main := get_tree().current_scene
        if main and main.has_method("on_zombie_killed"):
            main.on_zombie_killed()
        # Short collapse/fade-like scale animation makes kills readable; gameplay count updates immediately.
        var death_tween := create_tween()
        death_tween.set_parallel(true)
        death_tween.tween_property(self, "scale", Vector3(1.0, 0.12, 1.0), 0.32).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_IN)
        death_tween.tween_property(self, "position:y", position.y - 0.22, 0.32).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_IN)
        death_tween.chain().tween_callback(queue_free)
