const fs = require('fs');
const path = require('path');
const root = path.join(__dirname, '..');
const project = path.join(root, 'LastRescue_Godot_Project');
const audioDirector = fs.readFileSync(path.join(project, 'scripts/audio_director.gd'), 'utf8');
const voiceBlock = audioDirector.match(/const VOICE_FILES := \{([\s\S]*?)\n\}/);
if (!voiceBlock) throw new Error('VOICE_FILES dictionary missing');
const mapped = new Map();
for (const match of voiceBlock[1].matchAll(/"([^"]+)"\s*:\s*"(res:\/\/audio\/voices\/[^\"]+\.ogg)"/g)) mapped.set(match[1], match[2]);
const manifest = JSON.parse(fs.readFileSync(path.join(root, 'AUDIO_MANIFEST_STAGE32.json'), 'utf8'));
if (manifest.stage !== 32 || manifest.version !== '0.32.0') throw new Error('Stage 32 audio manifest version mismatch');
if (!manifest.voice_type.includes('expressively tuned synthetic prototype TTS')) throw new Error('TTS must be honestly labelled synthetic');
const all = [...manifest.persian_cues, ...manifest.english_cues];
if (all.length !== 32 || new Set(all).size !== 32) throw new Error('Expected 32 unique bilingual chapter 9–12 cues');
for (const cue of all) {
  if (!mapped.has(cue)) throw new Error(`Cue not registered in AudioDirector: ${cue}`);
  const relative = mapped.get(cue).replace(/^res:\/\//, '');
  const full = path.join(project, relative);
  if (!fs.existsSync(full)) throw new Error(`Voice file missing: ${relative}`);
  const bytes = fs.readFileSync(full);
  if (bytes.length < 1000 || bytes.subarray(0, 4).toString('ascii') !== 'OggS') throw new Error(`Invalid OGG container: ${relative}`);
}
for (const rel of ['audio/sfx/axe_swing.wav','audio/sfx/axe_impact.wav','audio/sfx/hero_hurt.wav','audio/sfx/zombie_attack.wav','audio/sfx/zombie_death.wav','audio/sfx/brute_roar.wav','audio/ambience/cemetery_wind.wav']) {
  const full = path.join(project, rel);
  if (!fs.existsSync(full) || fs.statSync(full).size < 1000) throw new Error(`Required SFX/ambience missing: ${rel}`);
}
const main = fs.readFileSync(path.join(project, 'scripts/main.gd'), 'utf8');
if (!main.includes('func _voice_cue(base_cue: String) -> String:') || !main.includes('return base_cue + "_en" if language == "en" else base_cue')) throw new Error('Language-specific voice cue selection missing');
for (const ch of ['9','10','11','12']) if (!main.includes(`stage_number == ${ch}`)) throw new Error(`Stage ${ch} voice playback branch missing`);
console.log(`PASS: ${all.length} bilingual OGG cues registered, present, and container-checked; all required SFX/ambience assets present.`);
console.log('INFO: voice assets are synthetic eSpeak prototypes with role-specific tuning, not human-recorded dubbing.');
