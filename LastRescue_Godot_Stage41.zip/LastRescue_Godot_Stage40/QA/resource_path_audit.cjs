const fs = require('fs');
const path = require('path');
const root = path.join(__dirname, '..');
const project = path.join(root, 'LastRescue_Godot_Project');
const candidates = [];
function walk(dir) {
  for (const item of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, item.name);
    if (item.isDirectory()) walk(full);
    else if (item.name.endsWith('.gd') || item.name.endsWith('.tscn')) candidates.push(full);
  }
}
walk(project);
const references = [];
for (const file of candidates) {
  const source = fs.readFileSync(file, 'utf8');
  const re = file.endsWith('.tscn') ? /path="res:\/\/([^"]+)"/g : /(?:preload|load)\(\s*"res:\/\/([^"]+)"\s*\)/g;
  for (const match of source.matchAll(re)) references.push({ from: path.relative(root, file), resource: match[1] });
}
const projectConfig = fs.readFileSync(path.join(project, 'project.godot'), 'utf8');
const scene = projectConfig.match(/run\/main_scene="res:\/\/([^"]+)"/);
if (!scene) throw new Error('Main scene resource is not configured');
references.push({ from: 'LastRescue_Godot_Project/project.godot', resource: scene[1] });
const missing = references.filter(ref => !fs.existsSync(path.join(project, ref.resource)));
if (missing.length) throw new Error('Missing Godot resource references:\n' + missing.map(x => `${x.from} -> res://${x.resource}`).join('\n'));
console.log(`PASS: ${references.length} static Godot resource references resolve to files.`);
console.log('NOTE: this is a path audit, not a replacement for Godot parsing/import or runtime tests.');
