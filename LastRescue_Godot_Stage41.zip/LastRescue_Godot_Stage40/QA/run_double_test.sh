#!/usr/bin/env sh
set -eu
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
cd "$ROOT"
node QA/ci_config_test.cjs
node QA/smoke_test.cjs
node QA/smoke_test.cjs
node QA/audio_asset_audit.cjs
node QA/audio_asset_audit.cjs
node QA/resource_path_audit.cjs
node QA/resource_path_audit.cjs
node QA/voice_lab_stage33.cjs
node QA/stage34_intensity_test.cjs
node QA/stage34_intensity_test.cjs
cmp Browser_Fallback/index.html Android_WebView_Wrapper/app/src/main/assets/index.html
grep -q 'versionCode 39' Android_WebView_Wrapper/app/build.gradle
grep -q "versionName '0.39.0'" Android_WebView_Wrapper/app/build.gradle
grep -q 'version/code=39' LastRescue_Godot_Project/export_presets.cfg
grep -q 'version/name="0.39.0"' LastRescue_Godot_Project/export_presets.cfg
printf '%s\n' 'PASS: release Android version markers'
printf '%s\n' 'PASS: double QA and asset parity'

node QA/stage35_neural_tts_test.cjs
node QA/stage36_voice_benchmark_test.cjs
node QA/stage35_neural_tts_test.cjs
node QA/stage36_voice_benchmark_test.cjs

node QA/stage37_voice_setup_test.cjs
node QA/stage37_voice_setup_test.cjs
grep -q 'versionCode 39' Android_WebView_Wrapper/app/build.gradle
grep -q "versionName '0.39.0'" Android_WebView_Wrapper/app/build.gradle
grep -q 'version/code=39' LastRescue_Godot_Project/export_presets.cfg
grep -q 'version/name="0.39.0"' LastRescue_Godot_Project/export_presets.cfg
printf '%s\n' 'PASS: Stage 37 version markers and repeated setup doctor'

node QA/stage38_progress_test.cjs
node QA/stage38_progress_test.cjs
grep -q 'versionCode 39' Android_WebView_Wrapper/app/build.gradle
grep -q "versionName '0.39.0'" Android_WebView_Wrapper/app/build.gradle
grep -q 'version/code=39' LastRescue_Godot_Project/export_presets.cfg
grep -q 'version/name="0.39.0"' LastRescue_Godot_Project/export_presets.cfg
cmp Browser_Fallback/index.html Android_WebView_Wrapper/app/src/main/assets/index.html
printf '%s\n' 'PASS: Stage 38 resume/fresh-start tests and release markers'

node QA/stage39_combat_ai_test.cjs
node QA/stage39_combat_ai_test.cjs
grep -q 'versionCode 39' Android_WebView_Wrapper/app/build.gradle
grep -q "versionName '0.39.0'" Android_WebView_Wrapper/app/build.gradle
grep -q 'version/code=39' LastRescue_Godot_Project/export_presets.cfg
grep -q 'version/name="0.39.0"' LastRescue_Godot_Project/export_presets.cfg
cmp Browser_Fallback/index.html Android_WebView_Wrapper/app/src/main/assets/index.html
printf '%s\n' 'PASS: Stage 39 combat steering tests and release markers'

node QA/stage40_impact_test.cjs
node QA/stage40_impact_test.cjs
grep -q 'versionCode 39' Android_WebView_Wrapper/app/build.gradle
grep -q "versionName '0.39.0'" Android_WebView_Wrapper/app/build.gradle
grep -q 'version/code=39' LastRescue_Godot_Project/export_presets.cfg
grep -q 'version/name="0.39.0"' LastRescue_Godot_Project/export_presets.cfg
cmp Browser_Fallback/index.html Android_WebView_Wrapper/app/src/main/assets/index.html
printf '%s\n' 'PASS: Stage 40 impact and brute slam tests plus release markers'
