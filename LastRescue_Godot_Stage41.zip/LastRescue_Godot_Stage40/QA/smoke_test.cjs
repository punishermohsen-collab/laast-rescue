const fs = require('fs');
const vm = require('vm');
const path = require('path');

const root = path.join(__dirname, '..');
const listeners = {};
const gradient = { addColorStop() {} };
const ctx = new Proxy({}, {
  get(o, k) {
    if (k === 'createLinearGradient' || k === 'createRadialGradient') return () => gradient;
    if (!(k in o)) o[k] = () => {};
    return o[k];
  },
  set(o, k, v) { o[k] = v; return true; }
});
function el(id) {
  return {
    id, style: {}, textContent: '', innerHTML: '', width: 0, height: 0, children: [],
    addEventListener(ev, fn) { (listeners[`${id}:${ev}`] ??= []).push(fn); },
    setPointerCapture() {}, getContext() { return ctx; }
  };
}
const els = {};
['game','overlay','stats','goal','card','start','attack','dodge','up','down','left','right'].forEach(id => els[id] = el(id));
const storage = new Map();
const sandbox = {
  console, Math, Set,
  localStorage: { getItem: k => storage.has(k) ? storage.get(k) : null, setItem: (k,v) => storage.set(k, String(v)) },
  devicePixelRatio: 1, innerWidth: 900, innerHeight: 650,
  performance: { now: () => 1000 },
  document: { getElementById: id => els[id] || (els[id] = el(id)) },
  window: { addEventListener(ev, fn) { (listeners[`window:${ev}`] ??= []).push(fn); } },
  requestAnimationFrame(fn) { sandbox.nextFrame = fn; }
};
vm.createContext(sandbox);
const html = fs.readFileSync(path.join(root, 'Browser_Fallback/index.html'), 'utf8');
let js = html.match(/<script>(.*?)<\/script>/s)?.[1];
if (!js) throw new Error('Browser game script not found');
// Test-only probes are injected into the same closure; no probes ship in the actual game.
const probe = `globalThis.__lrTest = {
  state: () => ({started, ended, won, kills, health, stage, totalZombies, medkitCount: medkits.filter(m => !m.used).length, zombieAlive: zombies.filter(z => z.alive).length}),
  forceWin: () => { started = true; ended = false; kills = totalZombies; for (const z of zombies) z.alive = false; player.x = girl.x; player.y = girl.y; update(0.016); },
  forceLoss: () => end(false),
  setStage: n => { stage = n; reset(); started = true; },
  setLanguage: n => { language = n; },
  restart: () => { reset(); started = true; },
  tick: dt => update(dt),
  testTelegraph: () => { reset(); started = true; const target = zombies[0]; for (const z of zombies) { z.x = W - 30; z.y = H - 30; z.emerge = 0; z.attackWindup = 0; z.attackCooldown = 0; } target.x = player.x; target.y = player.y; target.attackCooldown = 0; const before = health; update(0.016); const windup = target.attackWindup; const during = health; update(0.5); return {windup, before, during, after: health, cooldown: target.attackCooldown}; }
};`;
if (!/\}\)\(\);\s*$/.test(js)) throw new Error('Could not attach QA probes safely');
js = js.replace(/\}\)\(\);\s*$/, `${probe}\n})();`);
vm.runInContext(js, sandbox, { timeout: 3000 });
if (typeof sandbox.nextFrame !== 'function') throw new Error('RAF was not scheduled');
const telegraph = sandbox.__lrTest.testTelegraph();
if (!(telegraph.windup > 0 && telegraph.during === telegraph.before && telegraph.after < telegraph.during && telegraph.cooldown > 0)) throw new Error('Stage 35 telegraphed attack timing/damage/cooldown failed');
console.log('PASS: Stage 35 enemy warning wind-up occurs before damage and respects attack cooldown.');
sandbox.nextFrame(1000);
for (const fn of listeners['start:click'] || []) fn();
sandbox.nextFrame(1016);
for (const fn of listeners['window:keydown'] || []) fn({ key: 'Shift', repeat: false, preventDefault() {} });
sandbox.nextFrame(1032);
for (const fn of listeners['dodge:pointerdown'] || []) fn({ preventDefault() {} });
sandbox.nextFrame(1048);
for (const fn of listeners['attack:pointerdown'] || []) fn({ preventDefault() {} });
sandbox.nextFrame(1064);
for (let i = 0; i < 900; i++) sandbox.nextFrame(1080 + i * 16);
const stress = sandbox.__lrTest.state();
if (!stress.started) throw new Error('Game unexpectedly returned to intro during stress test');
// Long idle stress may legitimately end in defeat. The test now reports that honestly.
if (stress.ended && stress.health > 0 && !stress.won) throw new Error('Game ended without victory or player defeat');

sandbox.__lrTest.forceLoss();
if (!sandbox.__lrTest.state().ended || sandbox.__lrTest.state().won) throw new Error('Loss state not recorded');
if (!els.card.innerHTML.includes('شکست خوردی')) throw new Error('Loss dialogue/card missing');
const restartHandlers = listeners['restart:click'] || [];
if (!restartHandlers.length) throw new Error('Restart control not wired after loss');
restartHandlers[restartHandlers.length - 1]();
if (sandbox.__lrTest.state().ended || sandbox.__lrTest.state().health !== 100) throw new Error('Restart did not restore a playable state');

sandbox.__lrTest.forceWin();
const victory = sandbox.__lrTest.state();
if (!victory.ended || !victory.won) throw new Error('Rescue proximity did not trigger victory');
if (!storage.has('lastRescueBestStage')) throw new Error('Victory did not persist best-stage progress');
if (!els.card.innerHTML.includes('اسم تو رو هم می‌دونستن')) throw new Error('Stage 17 rescue dialogue missing');
const nextStageHandlers = listeners['restart:click'] || [];
if (!nextStageHandlers.length) throw new Error('Next-stage control not wired after victory');
nextStageHandlers[nextStageHandlers.length - 1]();
const nextStage = sandbox.__lrTest.state();
if (nextStage.stage !== 2 || nextStage.totalZombies !== 8 || nextStage.health <= 0 || nextStage.ended) throw new Error('Stage progression failed to increase wave and preserve playable health');
if (nextStage.medkitCount < 1) throw new Error('Stage 2 must provide at least one first-aid kit');
sandbox.__lrTest.forceWin();
if (!els.card.innerHTML.includes('راهرویی زیر کلیسا')) throw new Error('Stage 2 rescue dialogue missing');
const stage2WinHandlers = listeners['restart:click'] || [];
stage2WinHandlers[stage2WinHandlers.length - 1]();
const stage3 = sandbox.__lrTest.state();
if (stage3.stage !== 3 || stage3.totalZombies !== 10 || stage3.ended) throw new Error('Stage 3 progression failed');
sandbox.__lrTest.forceWin();
if (!els.card.innerHTML.includes('اون غول')) throw new Error('Stage 3 brute dialogue missing');
sandbox.__lrTest.setStage(7);
sandbox.__lrTest.setLanguage('fa');
sandbox.__lrTest.forceWin();
if (!els.card.innerHTML.includes('اسم خودم اینجاست')) throw new Error('Stage 7 Persian dialogue did not render');
sandbox.__lrTest.setLanguage('en');
sandbox.__lrTest.forceWin();
if (!els.card.innerHTML.includes('hundred years old')) throw new Error('Stage 7 English dialogue did not render');
sandbox.__lrTest.setStage(8);
sandbox.__lrTest.setLanguage('fa');
sandbox.__lrTest.forceWin();
if (!els.card.innerHTML.includes('منبع آلودگی')) throw new Error('Stage 8 Persian dialogue did not render');
sandbox.__lrTest.setLanguage('en');
sandbox.__lrTest.forceWin();
if (!els.card.innerHTML.includes('infection source is awakening')) throw new Error('Stage 8 English dialogue did not render');
sandbox.__lrTest.setStage(9);
sandbox.__lrTest.setLanguage('fa');
sandbox.__lrTest.forceWin();
if (!els.card.innerHTML.includes('اسم تو قبل از تولدت ثبت شده')) throw new Error('Stage 9 Persian dialogue did not render');
sandbox.__lrTest.setLanguage('en');
sandbox.__lrTest.forceWin();
if (!els.card.innerHTML.includes('registered before you were born')) throw new Error('Stage 9 English dialogue did not render');
sandbox.__lrTest.setStage(10);
sandbox.__lrTest.setLanguage('fa');
sandbox.__lrTest.forceWin();
if (!els.card.innerHTML.includes('این قلب زنده')) throw new Error('Stage 10 Persian dialogue did not render');
sandbox.__lrTest.setLanguage('en');
sandbox.__lrTest.forceWin();
if (!els.card.innerHTML.includes('every beat wakes the dead')) throw new Error('Stage 10 English dialogue did not render');
sandbox.__lrTest.setStage(11);
sandbox.__lrTest.setLanguage('fa');
sandbox.__lrTest.forceWin();
if (!els.card.innerHTML.includes('اسم‌هامون رو می‌خونن')) throw new Error('Stage 11 Persian dialogue did not render');
sandbox.__lrTest.setLanguage('en');
sandbox.__lrTest.forceWin();
if (!els.card.innerHTML.includes('reading our names')) throw new Error('Stage 11 English dialogue did not render');
sandbox.__lrTest.setStage(12);
sandbox.__lrTest.setLanguage('fa');
sandbox.__lrTest.forceWin();
if (!els.card.innerHTML.includes('برج مخابرات')) throw new Error('Stage 12 Persian dialogue did not render');
sandbox.__lrTest.setLanguage('en');
sandbox.__lrTest.forceWin();
if (!els.card.innerHTML.includes('last safe point')) throw new Error('Stage 12 English dialogue did not render');

for (const token of ['lastRescueBestStage','lightningWait','puddle glints shift gently','sparse drifting spores/embers','swingProgress','corpses.push','shakePower','dodgeGhosts.push','floating ember-runes','اسم تو رو هم می‌دونستن','راهرویی زیر کلیسا','stage%3===0','اون غول']) {
  if (!html.includes(token)) throw new Error(`Missing expected browser feature/story marker: ${token}`);
if (!html.includes('Math.min(2,1+Math.floor(stage/4))') || !html.includes('health-(z.brute?18:8)') || !html.includes('player.invuln=.8;') || !html.includes('attempts<12')) throw new Error('Stage 28 survival balance / guaranteed medkit placement missing');
}
const androidHtmlPath = path.join(root, 'Android_WebView_Wrapper/app/src/main/assets/index.html');
if (!fs.existsSync(androidHtmlPath)) throw new Error('Android WebView fallback package missing');
if (fs.readFileSync(androidHtmlPath, 'utf8') !== html) throw new Error('Browser and Android WebView HTML assets differ');
const godotMain = fs.readFileSync(path.join(root, 'LastRescue_Godot_Project/scripts/main.gd'), 'utf8');
if (!godotMain.includes('RitualEmber') || !godotMain.includes('اسم تو رو هم می‌دونستن') || !godotMain.includes('_start_next_stage') || !godotMain.includes('total_zombies = 6 + (stage_number - 1) * 2') || !godotMain.includes('راهروی سردابه') || !godotMain.includes('enemy.set("max_health", 150.0)') || !godotMain.includes('stage_number >= 3')) throw new Error('Godot Stage 18 progression/visual/dialogue enhancement missing');
const preset = fs.readFileSync(path.join(root, 'LastRescue_Godot_Project/export_presets.cfg'), 'utf8');
if (!preset.includes('name="Android"') || !preset.includes('package/unique_name="com.lastrescue.game"') || !preset.includes('architectures/arm64-v8a=true')) throw new Error('Android export preset missing required settings');
if (!preset.includes('screen/orientation=0')) throw new Error('Godot Android export is not configured for landscape');
if (!preset.includes('version/code=39') || !preset.includes('version/name="0.39.0"')) throw new Error('Godot Android export version marker mismatch');
const gradleApp = fs.readFileSync(path.join(root, 'Android_WebView_Wrapper/app/build.gradle'), 'utf8');
if (!gradleApp.includes('versionCode 39') || !gradleApp.includes("versionName '0.39.0'")) throw new Error('WebView Android version marker mismatch');
const workflow = fs.readFileSync(path.join(root, '.github/workflows/android-apk.yml'), 'utf8');
for (const token of ['Godot_v4.6-stable_linux.x86_64.zip','Godot_v4.6-stable_export_templates.tpz','--export-debug','actions/upload-artifact@v4']) if (!workflow.includes(token)) throw new Error(`Android CI workflow missing ${token}`);
if (workflow.indexOf('yes | sdkmanager --licenses') > workflow.indexOf('sdkmanager --install')) throw new Error('Android SDK licenses are accepted after package installation');
const audioDirector = fs.readFileSync(path.join(root, 'LastRescue_Godot_Project/scripts/audio_director.gd'), 'utf8');
if (!audioDirector.includes('play_voice_sequence') || !audioDirector.includes('intro_girl_01') || !audioDirector.includes('axe_swing') || !audioDirector.includes('Audio asset not installed yet')) throw new Error('Persian voice/SFX audio integration hooks missing');
if (!godotMain.includes('play_voice_sequence') || !godotMain.includes('AUDIO_DIRECTOR_SCRIPT') || !godotMain.includes('masked_tease_01')) throw new Error('Story dialogue not connected to audio director');
if (!fs.existsSync(path.join(root, 'PERSIAN_VOICE_ACTING_STAGE19_FA.md'))) throw new Error('Persian voice acting direction sheet missing');
if (!fs.existsSync(path.join(root, 'AUDIO_MANIFEST_STAGE19.json')) || !fs.existsSync(path.join(root, 'AUDIO_MANIFEST_STAGE20.json'))) throw new Error('Audio asset manifest missing');
const audioDir = path.join(root, 'LastRescue_Godot_Project/audio');
for (const f of ['sfx/axe_swing.wav','sfx/axe_impact.wav','sfx/hero_hurt.wav','sfx/zombie_attack.wav','sfx/zombie_death.wav','sfx/brute_roar.wav','ambience/cemetery_wind.wav']) if (!fs.existsSync(path.join(audioDir,f))) throw new Error(`Stage 20 audio asset missing: ${f}`);
if (!godotMain.includes('محراب زیرزمینی') || !godotMain.includes('تونل قربانیان') || !godotMain.includes('قلب آلودگی')) throw new Error('Stage 20 chapter dialogue missing');
if (!audioDirector.includes('AudioStreamWAV.LOOP_FORWARD')) throw new Error('Ambience loop mode not configured for WAV');
console.log('PASS: initialization, rendering, start, keyboard/touch dodge, attack handler, 900-frame JS stability, loss state, restart recovery, rescue victory, saved progress, next-stage wave scaling and stage-specific dialogue (including dynamic stages 7–12), Godot progression markers, Persian voice/SFX integration hooks, Android landscape preset, workflow ordering, and byte-identical WebView asset.');

console.log(`Stress-test outcome (not a balance test): ended=${stress.ended}, health=${stress.health}, won=${stress.won}; deterministic rescue path: PASS; stage-2, stage-3 and stage-4+ progression markers: PASS; WAV assets: PASS.`);

const browserHtml = fs.readFileSync(path.join(root, 'Browser_Fallback/index.html'), 'utf8');
if (!browserHtml.includes('languageToggle') || !browserHtml.includes('function applyLanguage') || !browserHtml.includes('Next Chapter') || !browserHtml.includes('LAST RESCUE')) throw new Error('Stage 21 bilingual language toggle missing');
if (!browserHtml.includes('lastRescueLanguage') || !browserHtml.includes('englishDialogue=stage===1') || !browserHtml.includes('You finally made it. Now you’ll learn why I chose you.')) throw new Error('Stage 23 persistent bilingual setting or chapter-specific English rescue dialogue missing');
if (!browserHtml.includes('if(ended)end(won)')) throw new Error('Stage 22 language toggle does not refresh end screen');
if (browserHtml.includes('مرحلهٔ هفدهم')) throw new Error('Browser title still points to an old chapter');
if (!godotMain.includes('func _toggle_language()') || !godotMain.includes('language = "en" if language == "fa" else "fa"')) throw new Error('Godot bilingual language toggle missing');
for (const token of ['var help_label: Label','var attack_button: Button','func _refresh_story_cards()','func _english_rescue_dialogue()','func _stage_transition_text()','Last Rescue','The Heart of the Infection','ending_body_label.autowrap_mode','help_label.text = "WASD / Arrows: Move']) if (!godotMain.includes(token)) throw new Error(`Godot bilingual UI/story fix missing: ${token}`);
console.log('PASS: Stage 21–25 bilingual browser/Godot UI, story-card, and version markers.');

// Stage 28: both build routes must be configured separately, with runtime smoke check and artifact upload.
const workflow25 = fs.readFileSync(path.join(root, '.github/workflows/android-apk.yml'), 'utf8');
if (!workflow25.includes('export-godot-3d') || !workflow25.includes('export-webview-fallback') || !workflow25.includes('--quit-after 45') || !workflow25.includes('LastRescue-Godot-3D-APK-v0.39.0') || !workflow25.includes('LastRescue-WebView-Fallback-APK-v0.39.0')) throw new Error('Dual Android build routes / Godot runtime smoke test missing');
if (!godotMain.includes('intro_story_label.autowrap_mode') || !godotMain.includes('transition_story_label.autowrap_mode') || !godotMain.includes('ending_body_label.autowrap_mode')) throw new Error('Story card mobile wrapping improvements missing');
if (!fs.readFileSync(path.join(root, 'LastRescue_Godot_Project/export_presets.cfg'), 'utf8').includes('version/code=39') || !fs.readFileSync(path.join(root, 'Android_WebView_Wrapper/app/build.gradle'), 'utf8').includes('versionCode 39')) throw new Error('current version markers missing');
console.log('PASS: Stage 30 dual APK workflows, headless Godot runtime gate, mobile story wrapping, and version markers.');

// Stage 28: bilingual chapter 7/8 dialogue, voice cue wiring, and release version.
const dialogue28 = JSON.parse(fs.readFileSync(path.join(root, 'DIALOGUE_SCRIPT_STAGE28_FA_EN.json'), 'utf8'));
if (!dialogue28.chapters['7'] || !dialogue28.chapters['8'] || dialogue28.chapters['7'].lines.length !== 4 || dialogue28.chapters['8'].lines.length !== 4) throw new Error('Stage 28 bilingual dialogue script incomplete');
for (const token of ['stage_number == 7','stage_number == 8','سلول‌های فراموش‌شده','دروازهٔ آهنین','stage7_girl_01','stage8_hero_01']) if (!godotMain.includes(token) && !audioDirector.includes(token)) throw new Error(`Godot stage 28 dialogue/cue missing: ${token}`);
for (const token of ['stage===7','stage===8','victims’ names are written on the walls','source is awakening']) if (!browserHtml.includes(token)) throw new Error(`Browser stage 28 dialogue missing: ${token}`);
if (!fs.existsSync(path.join(root, 'PERSIAN_VOICE_ACTING_STAGE28_FA.md'))) throw new Error('Stage 28 voice acting direction sheet missing');
if (!workflow.includes('LastRescue-Godot-3D-APK-v0.39.0') || !workflow.includes('LastRescue-WebView-Fallback-APK-v0.39.0')) throw new Error('Stage 32 artifact labels missing');
console.log('PASS: Stage 28 Persian/English chapters 7–8 dialogue, voice-cue catalog, dubbing notes, and artifact labels.');

// Stage 29: dedicated bilingual rescue dialogue for chapters 9 and 10.
for (const token of ['stage===9','stage===10','registered before you were born','every beat wakes the dead']) if (!browserHtml.includes(token)) throw new Error(`Stage 29 browser dialogue missing: ${token}`);
for (const token of ['if stage_number == 9','if stage_number == 10','بایگانی خاکستر','قلب زنده','stage9_hero_01','stage10_girl_01']) if (!godotMain.includes(token)) throw new Error(`Stage 29 Godot dialogue/cue missing: ${token}`);
const dialogue29 = JSON.parse(fs.readFileSync(path.join(root, 'DIALOGUE_SCRIPT_STAGE29_FA_EN.json'), 'utf8'));
if (dialogue29.chapters['9'].lines.length !== 4 || dialogue29.chapters['10'].lines.length !== 4) throw new Error('Stage 29 dialogue catalog incomplete');
for (const token of ['version/code=39','version/name="0.39.0"']) if (!preset.includes(token)) throw new Error(`current Godot version missing: ${token}`);
if (!gradleApp.includes('versionCode 39') || !gradleApp.includes("versionName '0.39.0'")) throw new Error('current WebView version markers missing');
if (!workflow.includes('LastRescue-Godot-3D-APK-v0.39.0') || !workflow.includes('LastRescue-WebView-Fallback-APK-v0.39.0')) throw new Error('Stage 32 dual build artifact labels missing');
console.log('PASS: Stage 29 bilingual chapters 9–10, Godot/browser integration, voice cue catalog, and historical stage markers.');


// Stage 30 regression checks: parser defect, cue map coverage, new bilingual chapters, and CI gate.
const stage30Main = fs.readFileSync(path.join(root, 'LastRescue_Godot_Project/scripts/main.gd'), 'utf8');
const processBlock = stage30Main.split('func _process(delta: float) -> void:')[1]?.split('func _show_end_card')[0] || '';
if (!processBlock.includes('for ritual_mark in captive.get_children():')) throw new Error('Godot ritual-mark processing loop missing');
if (/for ritual_mark in captive\.get_children\(\):\s*if ritual_mark is MeshInstance3D:\s*if ritual_mark is MeshInstance3D:/s.test(processBlock)) throw new Error('Duplicate unindented MeshInstance3D condition regression detected');
if ((processBlock.match(/if ritual_mark is MeshInstance3D:/g) || []).length !== 1) throw new Error('Ritual mark type guard must occur exactly once');
const stage30Audio = fs.readFileSync(path.join(root, 'LastRescue_Godot_Project/scripts/audio_director.gd'), 'utf8');
for (const cue of ['stage9_hero_01','stage9_girl_01','stage9_hero_02','stage9_masked_01','stage10_girl_01','stage10_hero_01','stage10_masked_01','stage10_girl_02','stage11_girl_01','stage11_hero_01','stage11_masked_01','stage11_girl_02','stage12_radio_01','stage12_hero_01','stage12_girl_01','stage12_masked_01']) if (!stage30Audio.includes('"'+cue+'"')) throw new Error(`Audio director cue not registered: ${cue}`);
const dialogue30 = JSON.parse(fs.readFileSync(path.join(root, 'DIALOGUE_SCRIPT_STAGE30_FA_EN.json'), 'utf8'));
for (const ch of ['9','10','11','12']) { const chapter = dialogue30.chapters[ch]; if (!chapter || !chapter.title_fa || !chapter.title_en || !Array.isArray(chapter.lines) || chapter.lines.length !== 4) throw new Error(`Stage ${ch} bilingual dialogue catalog incomplete`); for (const line of chapter.lines) if (!line.fa || !line.en || !line.voice) throw new Error(`Stage ${ch} dialogue line missing translation or cue`); }
for (const token of ['stage===11','stage===12','reading our names','last safe point']) if (!browserHtml.includes(token)) throw new Error(`Browser stage 30 chapter missing: ${token}`);
for (const token of ['stage_number == 11','stage_number == 12','هم‌سرایان توخالی','آخرین پیام','stage11_girl_01','stage12_radio_01']) if (!stage30Main.includes(token) && !stage30Audio.includes(token)) throw new Error(`Godot stage 30 dialogue/cue missing: ${token}`);
if (!workflow.includes('validate-project') || !workflow.includes('needs: validate-project') || !workflow.includes('node QA/smoke_test.cjs')) throw new Error('Android build jobs are not gated by CI QA');
for (const requiredPath of ['QA/**','Browser_Fallback/**','DIALOGUE_SCRIPT_*.json','AUDIO_MANIFEST_*.json','LastRescue_Godot_Project/audio/**']) if (!workflow.includes(requiredPath)) throw new Error(`GitHub Actions path filter misses ${requiredPath}`);
if (!preset.includes('version/code=39') || !preset.includes('version/name="0.39.0"') || !gradleApp.includes('versionCode 39') || !gradleApp.includes("versionName '0.39.0'")) throw new Error('current version markers are inconsistent');
console.log('PASS: Stage 30 regression guard for ritual-mark type guard, registered stage 9–12 voice cues, bilingual chapters 11–12, CI QA gating, path filters, and release markers.');


// Stage 31 remains as a historical baseline; current source is Stage 32.
const manifest31 = JSON.parse(fs.readFileSync(path.join(root, 'AUDIO_MANIFEST_STAGE31.json'), 'utf8'));
if (manifest31.version !== '0.31.0' || manifest31.persian_cues.length !== 16 || manifest31.english_cues.length !== 16) throw new Error('Historical Stage 31 bilingual audio manifest incomplete');
if (!manifest31.voice_type.includes('synthetic prototype TTS')) throw new Error('Stage 31 audio provenance must be explicit');

// Stage 32: expressive tuning, accurate speaker profiles, and current release markers.
const manifest32 = JSON.parse(fs.readFileSync(path.join(root, 'AUDIO_MANIFEST_STAGE32.json'), 'utf8'));
if (manifest32.stage !== 32 || manifest32.version !== '0.32.0' || manifest32.persian_cues.length !== 16 || manifest32.english_cues.length !== 16) throw new Error('Stage 32 bilingual audio manifest incomplete');
if (!manifest32.voice_type.includes('not human dubbing')) throw new Error('Stage 32 audio provenance must be explicit');
if (!manifest32.improvements.includes('correct masked_man profile mapping')) throw new Error('Masked-man voice profile regression not documented');
if (manifest32.files.length !== 32 || manifest32.files.some(f => !f.duration_seconds || f.bytes < 1000)) throw new Error('Stage 32 voice file inventory/duration metadata incomplete');
for (const cue of manifest32.persian_cues) if (!godotMain.includes(`_voice_cue(\"${cue}\")`)) throw new Error(`Persian/English cue selection missing for ${cue}`);
for (const token of ['node QA/audio_asset_audit.cjs','node QA/resource_path_audit.cjs','TOOLS/**']) if (!workflow.includes(token)) throw new Error(`Stage 32 CI audit/filter missing: ${token}`);
if (!fs.readFileSync(path.join(root, 'LastRescue_Godot_Project/project.godot'), 'utf8').includes('Stage 32 Expressive Dialogue Audio')) throw new Error('Stage 32 project title marker missing');
console.log('PASS: Stage 32 role-specific dialogue tuning, synthetic provenance, bilingual voice inventory, CI audit gate, and version marker.');
