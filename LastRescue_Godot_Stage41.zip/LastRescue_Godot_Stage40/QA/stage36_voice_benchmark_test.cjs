const fs=require('fs'),path=require('path'),root=path.join(__dirname,'..');
const script=fs.readFileSync(path.join(root,'TOOLS/run_voice_benchmark_stage36.py'),'utf8');
for(const token of ['Piper neural TTS','is_neural','BLOCKED_NO_PIPER_RUNTIME','wav_info','synthesize_wav']) if(!script.includes(token)) throw Error('Missing voice benchmark safeguard: '+token);
const report=JSON.parse(fs.readFileSync(path.join(root,'TOOLS/voice_benchmark_stage36/output/benchmark_report_stage36.json'),'utf8'));
if(report.stage!==36) throw Error('Wrong benchmark stage');
if(report.baseline.status!=='PASS'||report.baseline.is_neural!==false||report.baseline.generated.length!==3) throw Error('Expected three explicitly non-neural baseline WAVs');
if(report.neural.status==='PASS' && report.neural.generated.length===0) throw Error('Neural PASS cannot have zero generated samples');
for(const sample of report.baseline.generated){if(!sample.file)throw Error('Missing baseline file metadata');const f=path.join(root,'TOOLS/voice_benchmark_stage36/output',sample.file);if(!fs.existsSync(f)||fs.statSync(f).size<1000)throw Error('Missing/empty sample '+f);}
const mirror=fs.readFileSync(path.join(root,'Browser_Fallback/index.html'),'utf8');const webview=fs.readFileSync(path.join(root,'Android_WebView_Wrapper/app/src/main/assets/index.html'),'utf8');if(mirror!==webview)throw Error('Browser/WebView mismatch');
console.log('PASS: Stage 36 voice benchmark reports three valid eSpeak baseline WAVs without mislabeling them as neural');
console.log('PASS: Neural status remains honest; no Piper model/runtime means neural audio is not claimed');
