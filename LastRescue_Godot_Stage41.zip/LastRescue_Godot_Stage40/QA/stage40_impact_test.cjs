const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'Browser_Fallback/index.html'), 'utf8');
const wrapper = fs.readFileSync(path.join(root, 'Android_WebView_Wrapper/app/src/main/assets/index.html'), 'utf8');
if (html !== wrapper) throw new Error('Browser and Android WebView gameplay assets differ');
for (const token of ['stagger:0','knockX:0','slamFlash:0','best.stagger=best.brute?.12:.24','best.knockX=','const slamHit=z.brute&&d<=z.r+player.r+66','z.slamFlash=.42','Stage 40: combat feedback']) {
  if (!html.includes(token)) throw new Error(`Stage 40 browser combat feature missing: ${token}`);
}
if (!html.includes('rgba(228,92,52') || !html.includes('z.brute&&z.slamFlash>0')) throw new Error('Brute slam shockwave visual missing');
const zombie = fs.readFileSync(path.join(root, 'LastRescue_Godot_Project/scripts/zombie.gd'), 'utf8');
for (const token of ['@export var is_brute: bool = false','brute_windup_timer','brute_slam_cooldown','Stage 40: the brute\'s slow ground slam','knockback_velocity = push.normalized()']) {
  if (!zombie.includes(token)) throw new Error(`Stage 40 Godot feature missing: ${token}`);
}
const main = fs.readFileSync(path.join(root, 'LastRescue_Godot_Project/scripts/main.gd'), 'utf8');
if (!main.includes('enemy.set("is_brute", true)')) throw new Error('Brute special attack not enabled by main scene');
const gradle = fs.readFileSync(path.join(root, 'Android_WebView_Wrapper/app/build.gradle'), 'utf8');
const preset = fs.readFileSync(path.join(root, 'LastRescue_Godot_Project/export_presets.cfg'), 'utf8');
if (!gradle.includes('versionCode 39') || !gradle.includes("versionName '0.39.0'") || !preset.includes('version/code=39') || !preset.includes('version/name="0.39.0"')) throw new Error('Stage 40 release markers mismatch');
console.log('PASS: Stage 40 axe knockback/stagger, brute slam telegraph/radius/shockwave, Godot parity markers, version 0.39.0');
