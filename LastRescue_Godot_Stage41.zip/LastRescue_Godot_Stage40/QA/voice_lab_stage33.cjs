const fs = require('fs');
const path = require('path');
const root = path.join(__dirname, '..');
const project = path.join(root, 'LastRescue_Godot_Project');
const dir = path.join(project, 'audio', 'voice_lab_stage33');
const names = ['01_baseline', '02_expressive', '03_expressive_room'];
for (const name of names) {
  const ogg = path.join(dir, name + '.ogg');
  const wav = path.join(dir, name + '.wav');
  if (!fs.existsSync(ogg) || fs.statSync(ogg).size < 5000) throw new Error('Missing/short OGG variant: ' + name);
  if (!fs.existsSync(wav) || fs.statSync(wav).size < 10000) throw new Error('Missing/short WAV variant: ' + name);
  const bytes = fs.readFileSync(ogg);
  if (bytes.subarray(0, 4).toString('ascii') !== 'OggS') throw new Error('Invalid OGG container: ' + name);
}
const audio = fs.readFileSync(path.join(project, 'scripts/audio_director.gd'), 'utf8');
if (!audio.includes('randf_range(0.98, 1.02)')) throw new Error('Small per-line pitch variation missing');
const manifest = JSON.parse(fs.readFileSync(path.join(root, 'VOICE_LAB_MANIFEST_STAGE33.json'), 'utf8'));
if (manifest.stage !== 33 || manifest.variants.length !== 3) throw new Error('Stage 33 A/B manifest incomplete');
console.log('PASS: Stage 33 has three WAV/OGG voice variants, valid OGG headers, and narrowly randomized playback pitch (stage 34 range).');
console.log('LIMIT: TTS remains synthetic; neural model, Godot runtime, APK, and device playback are not verified.');
