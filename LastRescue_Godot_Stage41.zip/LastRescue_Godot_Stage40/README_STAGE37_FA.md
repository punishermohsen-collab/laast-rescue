# آخرین نجات — مرحلهٔ ۳۷

## تغییرات
- ابزار `voice_setup_doctor_stage37.py` برای بررسی آفلاین وجود Piper، مدل‌های ONNX، فایل‌های JSON متناظر و wheelهای محلی.
- صفحهٔ شنیداری فارسی برای مقایسهٔ سه baseline فعلی (ترس دختر، هشدار قهرمان، آرامش دختر).
- تست خودکار اختصاصی مرحلهٔ ۳۷ و اجرای دوبارهٔ آن در مجموعهٔ QA.
- نسخهٔ Android wrapper و Godot export markers به `0.36.0` و `versionCode 36` ارتقا یافت.

## نتیجهٔ صادقانه
این مرحله زیرساخت تشخیص و شنیدن را بهتر می‌کند؛ موتور عصبی را جادویی فعال نمی‌کند. اگر Piper یا مدل در دسترس نباشد، گزارش وضعیت مسدودبودن را مشخص می‌کند. نمونه‌های صوتی موجود eSpeak هستند، نه عصبی. اجرای واقعی Godot و ساخت APK در این محیط هنوز تأیید نشده است.

## تست
از ریشهٔ پروژه:

```bash
sh QA/run_double_test.sh
python3 -m py_compile TOOLS/voice_benchmark_stage37/voice_setup_doctor_stage37.py
node --check QA/stage37_voice_setup_test.cjs
```
