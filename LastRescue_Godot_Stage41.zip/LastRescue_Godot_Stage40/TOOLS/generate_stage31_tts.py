#!/usr/bin/env python3
"""Generate prototype Persian/English chapter 9–12 voice cues using eSpeak + FFmpeg.
This is synthetic TTS for testing, not professional human dubbing.
"""
import json, pathlib, subprocess, tempfile
ROOT = pathlib.Path(__file__).resolve().parents[1]
PROJECT = ROOT / 'LastRescue_Godot_Project'
DATA = json.loads((ROOT / 'DIALOGUE_SCRIPT_STAGE30_FA_EN.json').read_text(encoding='utf-8'))
OUT = PROJECT / 'audio' / 'voices'
OUT.mkdir(parents=True, exist_ok=True)
PITCH = {'hero': 42, 'girl': 60, 'masked': 28, 'radio': 38}
created = []
with tempfile.TemporaryDirectory(prefix='lastrescue-tts-') as td:
    td = pathlib.Path(td)
    for chapter_id in ('9', '10', '11', '12'):
        for line in DATA['chapters'][chapter_id]['lines']:
            cue = line['voice']
            speaker = line.get('speaker', 'hero')
            for lang, text in (('fa', line['fa']), ('en', line['en'])):
                cue_id = cue if lang == 'fa' else cue + '_en'
                wav = td / f'{cue_id}.wav'
                ogg = OUT / f'{cue_id}.ogg'
                pitch = PITCH.get(speaker, 45) if lang == 'fa' else min(75, PITCH.get(speaker, 45) + 4)
                subprocess.run(['espeak', '-v', lang, '-s', '140', '-p', str(pitch), '-w', str(wav), text], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
                subprocess.run(['ffmpeg', '-y', '-loglevel', 'error', '-i', str(wav), '-c:a', 'libvorbis', '-q:a', '4', str(ogg)], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
                created.append({'cue': cue_id, 'language': lang, 'file': str(ogg.relative_to(PROJECT)), 'bytes': ogg.stat().st_size})
print(json.dumps({'engine': 'eSpeak + FFmpeg/libvorbis', 'kind': 'synthetic prototype TTS, not human dubbing', 'created': len(created), 'files': created}, ensure_ascii=False, indent=2))
