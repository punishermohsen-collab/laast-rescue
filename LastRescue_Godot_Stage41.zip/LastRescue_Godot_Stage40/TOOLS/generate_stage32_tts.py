#!/usr/bin/env python3
"""Create a more expressive synthetic dialogue pass for Last Rescue.
Uses local eSpeak + FFmpeg only. It remains synthetic TTS, not human dubbing.
"""
import json, pathlib, subprocess, tempfile, wave, contextlib
ROOT = pathlib.Path(__file__).resolve().parents[1]
PROJECT = ROOT / 'LastRescue_Godot_Project'
DATA = json.loads((ROOT / 'DIALOGUE_SCRIPT_STAGE30_FA_EN.json').read_text(encoding='utf-8'))
OUT = PROJECT / 'audio' / 'voices'
OUT.mkdir(parents=True, exist_ok=True)
# eSpeak pitch is 0..99; use speaker-specific pace and pitch rather than one generic voice.
PROFILES = {
    'hero': {'fa': (126, 39, 155), 'en': (132, 43, 155), 'filter': 'highpass=f=85,lowpass=f=7600,equalizer=f=180:t=q:w=1:g=1.2,equalizer=f=2600:t=q:w=1:g=1.0,acompressor=threshold=0.10:ratio=2.2:attack=12:release=100'},
    'girl': {'fa': (150, 62, 150), 'en': (154, 66, 150), 'filter': 'highpass=f=100,lowpass=f=7800,equalizer=f=240:t=q:w=1:g=0.8,equalizer=f=3000:t=q:w=1:g=1.2,acompressor=threshold=0.11:ratio=1.8:attack=10:release=90'},
    'masked_man': {'fa': (114, 25, 145), 'en': (119, 29, 145), 'filter': 'highpass=f=75,lowpass=f=5200,equalizer=f=150:t=q:w=1:g=1.7,equalizer=f=1800:t=q:w=1:g=-1.0,acompressor=threshold=0.09:ratio=2.5:attack=15:release=120,aecho=0.8:0.88:38:0.055'},
    'radio': {'fa': (128, 35, 145), 'en': (132, 40, 145), 'filter': 'highpass=f=280,lowpass=f=3200,equalizer=f=1100:t=q:w=0.8:g=1.2,acompressor=threshold=0.09:ratio=2.8:attack=8:release=85,aecho=0.7:0.78:55:0.06'},
}
created=[]
with tempfile.TemporaryDirectory(prefix='lastrescue-stage32-') as temp:
    temp=pathlib.Path(temp)
    for chapter_id in ('9','10','11','12'):
        for line in DATA['chapters'][chapter_id]['lines']:
            cue=line['voice']
            speaker=line.get('speaker','hero')
            profile=PROFILES.get(speaker, PROFILES['hero'])
            for lang, text in (('fa',line['fa']),('en',line['en'])):
                cue_id=cue if lang=='fa' else cue+'_en'
                wav=temp/(cue_id+'.wav')
                ogg=OUT/(cue_id+'.ogg')
                speed,pitch,amp=profile[lang]
                voice='fa' if lang=='fa' else 'en-us'
                # Preserve natural punctuation and let eSpeak produce phrase contours.
                subprocess.run(['espeak','-v',voice,'-s',str(speed),'-p',str(pitch),'-a',str(amp),'-g','3','-w',str(wav),text],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
                af=profile['filter']+',alimiter=limit=0.92,loudnorm=I=-19:TP=-2:LRA=8'
                subprocess.run(['ffmpeg','-y','-loglevel','error','-i',str(wav),'-af',af,'-c:a','libvorbis','-q:a','5',str(ogg)],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
                with contextlib.closing(wave.open(str(wav),'rb')) as wf: duration=round(wf.getnframes()/wf.getframerate(),2)
                created.append({'cue':cue_id,'language':lang,'speaker':speaker,'file':str(ogg.relative_to(PROJECT)),'bytes':ogg.stat().st_size,'duration_seconds':duration,'profile':f'{speed}wpm/pitch{pitch}'})
manifest={
 'stage':32,'version':'0.32.0','engine':'eSpeak + FFmpeg/libvorbis','voice_type':'expressively tuned synthetic prototype TTS; not human dubbing',
 'improvements':['speaker-specific speed and pitch','correct masked_man profile mapping','role-specific EQ and compression','subtle masked/radio acoustic treatment','consistent loudness normalization'],
 'limitations':['prosody and emotion remain limited by eSpeak','Persian voice is synthetic; professional neural TTS or human actors would sound more natural'],
 'persian_cues':[x['cue'] for x in created if x['language']=='fa'],'english_cues':[x['cue'] for x in created if x['language']=='en'],'files':created
}
(ROOT/'AUDIO_MANIFEST_STAGE32.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'engine':manifest['engine'],'created':len(created),'total_bytes':sum(x['bytes'] for x in created),'manifest':str(ROOT/'AUDIO_MANIFEST_STAGE32.json')},ensure_ascii=False,indent=2))
