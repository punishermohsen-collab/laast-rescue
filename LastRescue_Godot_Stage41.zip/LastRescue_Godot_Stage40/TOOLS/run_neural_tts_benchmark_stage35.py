#!/usr/bin/env python3
"""Generate comparable Persian speech samples with locally available Piper neural models.

This script does not download models or fall back to eSpeak. Missing models are reported
as BLOCKED, so the report cannot mistake a non-neural voice for a neural test.
"""
from __future__ import annotations
import argparse, json, sys, time, wave
from pathlib import Path

TEST_LINES = {
    "girl_fear": "نه... نزدیک نشو! کمکم کن، خواهش می‌کنم!",
    "hero_warning": "عقب وایسا! دارم میام نجاتت بدم!",
    "girl_relief": "فکر کردم دیگه هیچ‌وقت از اینجا بیرون نمی‌رم... ممنون که برگشتی."
}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--model', action='append', default=[], help='Path to a Piper .onnx model; repeat for A/B comparison')
    parser.add_argument('--out', default='TOOLS/voice_benchmark_stage35/output', help='Output directory')
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    out = (root / args.out).resolve() if not Path(args.out).is_absolute() else Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    models = [Path(x).expanduser().resolve() for x in args.model]
    if not models:
        models = [root / 'TOOLS/voice_benchmark_stage35/models/fa_IR-mana-medium.onnx',
                  root / 'TOOLS/voice_benchmark_stage35/models/fa_IR-gyro-medium.onnx',
                  root / 'TOOLS/voice_benchmark_stage35/models/fa_IR-amir-medium.onnx']
    missing = [str(p) for p in models if not p.is_file()]
    try:
        from piper import PiperVoice
    except Exception as exc:
        report = {'status':'BLOCKED', 'reason':f'Piper Python package unavailable: {type(exc).__name__}: {exc}', 'models_missing':missing, 'generated':[], 'test_lines':TEST_LINES}
        (out/'benchmark_report.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
        print(json.dumps(report, ensure_ascii=False, indent=2)); return 2
    generated=[]
    for model_path in models:
        if not model_path.is_file():
            continue
        try:
            start=time.monotonic(); voice=PiperVoice.load(str(model_path)); load_s=time.monotonic()-start
            for label, text in TEST_LINES.items():
                target=out/f'{model_path.stem}_{label}.wav'
                start=time.monotonic()
                with wave.open(str(target), 'wb') as wav_file:
                    voice.synthesize_wav(text, wav_file)
                elapsed=time.monotonic()-start
                with wave.open(str(target),'rb') as wav_file:
                    frames=wav_file.getnframes(); rate=wav_file.getframerate(); channels=wav_file.getnchannels()
                if frames < rate//2:
                    raise RuntimeError(f'Generated sample unexpectedly short: {target}')
                generated.append({'model':str(model_path),'line':label,'text':text,'file':str(target.relative_to(out.parent)), 'duration_seconds':round(frames/rate,3),'sample_rate':rate,'channels':channels,'generation_seconds':round(elapsed,3),'model_load_seconds':round(load_s,3)})
        except Exception as exc:
            generated.append({'model':str(model_path),'error':f'{type(exc).__name__}: {exc}'})
    ok=[x for x in generated if 'file' in x]
    status='PASS' if ok and not missing and len(ok)==len(models)*len(TEST_LINES) else ('PARTIAL' if ok else 'BLOCKED')
    report={'status':status,'engine':'Piper neural TTS','models_missing':missing,'generated':generated,'test_lines':TEST_LINES,'note':'Technical generation and file integrity are measurable here; emotional naturalness and Persian pronunciation require listening by a Persian speaker.'}
    (out/'benchmark_report.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0 if status=='PASS' else (1 if status=='PARTIAL' else 2)

if __name__=='__main__':
    sys.exit(main())
