#!/usr/bin/env python3
"""Stage 36: generate a clearly labeled local Persian eSpeak baseline and try Piper models if available.

Never labels eSpeak output as neural. Neural generation is marked blocked when the Piper
runtime or model files are absent. The script performs no network access or downloads.
"""
from __future__ import annotations
import argparse, json, shutil, subprocess, sys, time, wave
from pathlib import Path

TEST_LINES = {
    "girl_fear": "نه... نزدیک نشو! کمکم کن، خواهش می‌کنم!",
    "hero_warning": "عقب وایسا! دارم میام نجاتت بدم!",
    "girl_relief": "فکر کردم دیگه هیچ‌وقت از اینجا بیرون نمی‌رم... ممنون که برگشتی."
}
DEFAULT_MODELS = [
    ("Piper Mana Persian", "TOOLS/voice_benchmark_stage35/models/fa_IR-mana-medium.onnx"),
    ("Piper Gyro Persian", "TOOLS/voice_benchmark_stage35/models/fa_IR-gyro-medium.onnx"),
    ("Piper Amir Persian", "TOOLS/voice_benchmark_stage35/models/fa_IR-amir-medium.onnx"),
]

def wav_info(path: Path) -> dict:
    with wave.open(str(path), "rb") as w:
        frames, rate, channels, width = w.getnframes(), w.getframerate(), w.getnchannels(), w.getsampwidth()
    if rate <= 0 or frames < rate // 4:
        raise RuntimeError(f"Invalid or suspiciously short WAV: {path}")
    return {"duration_seconds": round(frames/rate, 3), "sample_rate": rate, "channels": channels, "sample_width_bytes": width}

def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--model', action='append', default=[], help='Piper .onnx path; repeat to compare models')
    parser.add_argument('--out', default='TOOLS/voice_benchmark_stage36/output', help='Output directory')
    parser.add_argument('--skip-espeak', action='store_true', help='Skip baseline generation')
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    out_arg = Path(args.out).expanduser()
    out = (root / out_arg).resolve() if not out_arg.is_absolute() else out_arg.resolve()
    out.mkdir(parents=True, exist_ok=True)
    report = {"stage":36, "status":"BLOCKED_NEURAL_BUT_BASELINE_CHECKED", "test_lines":TEST_LINES,
              "baseline":{"engine":"eSpeak","is_neural":False,"status":"NOT_RUN","generated":[]},
              "neural":{"engine":"Piper neural TTS","status":"BLOCKED","generated":[],"models_missing":[]},
              "comparison_note":"File generation and duration are measurable; naturalness, emotion and Persian pronunciation need listening by a fluent Persian speaker."}
    espeak = shutil.which('espeak') or shutil.which('espeak-ng')
    if args.skip_espeak:
        report['baseline']['status'] = 'SKIPPED_BY_REQUEST'
    elif not espeak:
        report['baseline']['status'] = 'BLOCKED_NO_ESPEAK_EXECUTABLE'
    else:
        for label, text in TEST_LINES.items():
            target = out / f'espeak_fa_{label}.wav'
            start = time.monotonic()
            try:
                proc = subprocess.run([espeak, '-v', 'fa', '-s', '145', '-w', str(target), text], capture_output=True, text=True, timeout=30)
                if proc.returncode != 0:
                    raise RuntimeError((proc.stderr or proc.stdout or f'exit {proc.returncode}').strip())
                meta = wav_info(target)
                report['baseline']['generated'].append({"line":label,"text":text,"file":target.name,**meta,"generation_seconds":round(time.monotonic()-start,3)})
            except Exception as exc:
                report['baseline']['generated'].append({"line":label,"error":f"{type(exc).__name__}: {exc}"})
        report['baseline']['status'] = 'PASS' if len([x for x in report['baseline']['generated'] if 'file' in x]) == len(TEST_LINES) else 'PARTIAL'
    models = [Path(x).expanduser().resolve() for x in args.model] if args.model else [(root / p).resolve() for _,p in DEFAULT_MODELS]
    report['neural']['models_missing'] = [str(p) for p in models if not p.is_file()]
    try:
        from piper import PiperVoice
    except Exception as exc:
        report['neural']['reason'] = f'Piper Python package unavailable: {type(exc).__name__}: {exc}'
        report['neural']['status'] = 'BLOCKED_NO_PIPER_RUNTIME'
        PiperVoice = None
    if PiperVoice is not None:
        for model_path in models:
            if not model_path.is_file():
                continue
            try:
                load_start = time.monotonic(); voice = PiperVoice.load(str(model_path)); load_seconds = time.monotonic()-load_start
                for label,text in TEST_LINES.items():
                    target = out / f'{model_path.stem}_{label}.wav'; start = time.monotonic()
                    with wave.open(str(target),'wb') as wf: voice.synthesize_wav(text,wf)
                    report['neural']['generated'].append({"model":model_path.name,"line":label,"text":text,"file":target.name,**wav_info(target),"generation_seconds":round(time.monotonic()-start,3),"model_load_seconds":round(load_seconds,3)})
            except Exception as exc:
                report['neural']['generated'].append({"model":str(model_path),"error":f'{type(exc).__name__}: {exc}'})
        count = len([x for x in report['neural']['generated'] if 'file' in x])
        report['neural']['status'] = 'PASS' if count == len(models)*len(TEST_LINES) and not report['neural']['models_missing'] else ('PARTIAL' if count else 'BLOCKED')
    if report['neural']['status'] != 'PASS':
        report['status'] = 'NEURAL_BLOCKED_BASELINE_AVAILABLE' if report['baseline']['status'] == 'PASS' else 'NEURAL_AND_BASELINE_BLOCKED'
    else:
        report['status'] = 'NEURAL_PASS'
    (out/'benchmark_report_stage36.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(report,ensure_ascii=False,indent=2))
    return 0 if report['baseline']['status'] in ('PASS','SKIPPED_BY_REQUEST') or report['neural']['status']=='PASS' else 2

if __name__ == '__main__':
    sys.exit(main())
