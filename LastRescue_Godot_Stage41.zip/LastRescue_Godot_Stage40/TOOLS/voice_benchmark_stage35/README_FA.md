# آزمایش گفتار عصبی فارسی — مرحله ۳۵

این ابزار فقط Piper واقعی را می‌سنجد؛ اگر موتور یا مدل در دسترس نباشد، نتیجه را `BLOCKED` ثبت می‌کند و به eSpeak تغییر مسیر نمی‌دهد.

## مدل‌های پیشنهادی برای مقایسه

- **Mana Persian Piper** — مدل `fa_IR-mana-medium.onnx`، مناسب بررسی وضوح و روانی فارسی: https://huggingface.co/MahtaFetrat/Mana-Persian-Piper
- **Gyro** — مدل `fa_IR-gyro-medium.onnx`: https://huggingface.co/gyroing/persian-tts-piper
- **Amir** — مدل `fa_IR-amir-medium.onnx`: https://huggingface.co/rhasspy/piper-voices/tree/v1.0.0/fa/fa_IR/amir/medium

برای هر مدل، فایل `.onnx` و فایل پیکربندی هم‌نام `.onnx.json` را در پوشه `models/` قرار بده. نصب یک‌بارهٔ محیط پایتون: `python -m pip install piper-tts`.

## اجرا

```bash
python TOOLS/run_neural_tts_benchmark_stage35.py
```

یا مسیر مدل‌ها را دستی بده:

```bash
python TOOLS/run_neural_tts_benchmark_stage35.py --model /path/to/fa_IR-mana-medium.onnx --model /path/to/fa_IR-gyro-medium.onnx
```

سه جملهٔ یکسان برای هر مدل ساخته می‌شود: ترس دختر، هشدار قهرمان و آرامش پس از نجات. فایل‌های WAV و `benchmark_report.json` در پوشهٔ خروجی قرار می‌گیرند. برای داوری حس و طبیعی‌بودن، نمونه‌ها باید با صدای یکسان گوشی و بلندی نزدیک شنیده شوند؛ صرفاً PASS فنی به معنی صدای انسانی نیست.

## وضعیت این محیط در زمان ساخت مرحلهٔ ۳۵

دسترسی DNS به `huggingface.co` خطای `Could not resolve host` داد و Piper/مدل عصبی از قبل نصب نبود. بنابراین **تولید صدای عصبی واقعی در این نوبت مسدود است**؛ هیچ فایل eSpeak به‌عنوان خروجی عصبی جا زده نشده است. ابزار مقایسه آماده است تا پس از فراهم‌شدن مدل اجرا شود.
