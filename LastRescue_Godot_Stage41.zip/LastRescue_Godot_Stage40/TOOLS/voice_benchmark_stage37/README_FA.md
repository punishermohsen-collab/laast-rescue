# آزمایشگاه صدای مرحلهٔ ۳۷

این مرحله یک مسیر **آفلاین‌محور** برای تشخیص آماده‌بودن Piper اضافه می‌کند؛ خودش مدل عصبی دانلود یا تولید نمی‌کند.

## بررسی وضعیت محیط و مدل‌ها
از ریشهٔ پروژه:

```bash
python3 TOOLS/voice_benchmark_stage37/voice_setup_doctor_stage37.py
```

اسکریپت وجود بستهٔ `piper-tts`، فایل‌های مدل `.onnx`، فایل پیکربندی متناظر `.onnx.json` و wheelهای محلی را بررسی و گزارش JSON تولید می‌کند. برای اسکن مسیر دلخواه:

```bash
python3 TOOLS/voice_benchmark_stage37/voice_setup_doctor_stage37.py --model-dir /path/to/models --wheel-dir /path/to/wheels
```

## نصب بدون اینترنت
اگر بسته‌ها و تمام وابستگی‌ها را از قبل به شکل wheel تهیه کرده‌ای، همهٔ آن‌ها را در `TOOLS/voice_benchmark_stage37/wheels/` بگذار و اجرا کن:

```bash
python -m pip install --no-index --find-links TOOLS/voice_benchmark_stage37/wheels piper-tts
```

این دستور فقط از فایل‌های محلی استفاده می‌کند و اگر وابستگی لازم موجود نباشد نصب شکست می‌خورد. مدل Piper و فایل JSON متناظر باید جداگانه و از منبع معتبر تهیه شوند؛ این بسته شامل مدل عصبی نیست.

## شنیدن نمونه‌ها
`audition_stage37.html` را در مرورگر باز کن. سه نمونهٔ موجود eSpeak و صرفاً baseline هستند؛ خشک‌بودن آن‌ها نشانهٔ شکست مرحله نیست، اما به معنی حل‌شدن صدای طبیعی هم نیست.

## اجرای بنچمارک عصبی
پس از نصب Piper و قرار دادن مدل:

```bash
python TOOLS/run_voice_benchmark_stage36.py --model TOOLS/voice_benchmark_stage37/models/MODEL.onnx
```

نتیجهٔ واقعی در گزارش Stage 36 ثبت می‌شود. تولید عصبی فقط وقتی تأیید می‌شود که فایل WAV از خود Piper تولید و اعتبارسنجی شود.
