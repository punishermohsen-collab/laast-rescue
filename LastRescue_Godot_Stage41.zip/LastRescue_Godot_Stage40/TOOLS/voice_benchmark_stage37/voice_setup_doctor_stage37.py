#!/usr/bin/env python3
"""Offline-first diagnostic for Persian TTS assets. Does not download anything."""
from __future__ import annotations
import argparse, importlib.util, json, os, platform, shutil, subprocess, sys
from pathlib import Path

def main() -> int:
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root', default='.', help='Project root')
    p.add_argument('--model-dir', default='TOOLS/voice_benchmark_stage37/models', help='Directory containing .onnx models and matching .onnx.json configs')
    p.add_argument('--wheel-dir', default='TOOLS/voice_benchmark_stage37/wheels', help='Optional directory of locally downloaded Python wheels')
    args=p.parse_args(); root=Path(args.root).resolve(); md=(root/args.model_dir).resolve(); wd=(root/args.wheel_dir).resolve()
    models=sorted(md.glob('*.onnx')) if md.is_dir() else []
    found=[]
    for m in models:
        cfg=Path(str(m)+'.json')
        found.append({'model':str(m.relative_to(root)) if m.is_relative_to(root) else str(m), 'size_bytes':m.stat().st_size,
                      'config':str(cfg.relative_to(root)) if cfg.is_relative_to(root) else str(cfg), 'config_exists':cfg.is_file()})
    wheels=sorted(w.name for w in wd.glob('*.whl')) if wd.is_dir() else []
    piperspec=importlib.util.find_spec('piper')
    espeak=shutil.which('espeak-ng') or shutil.which('espeak')
    try:
        import importlib.metadata as im
        piper_version=im.version('piper-tts')
    except Exception: piper_version=None
    result={'stage':37,'python':sys.version.split()[0],'platform':platform.platform(),'project_root':str(root),
      'piper_import_available':piperspec is not None,'piper_tts_version':piper_version,'espeak_executable':espeak,
      'model_directory':str(md),'models':found,'model_count':len(found),'models_with_config':sum(x['config_exists'] for x in found),
      'wheel_directory':str(wd),'local_wheels':wheels,
      'status':'READY_FOR_NEURAL_TEST' if piperspec and found and all(x['config_exists'] for x in found) else ('PARTIAL_LOCAL_ASSETS' if found or wheels else 'NEURAL_BLOCKED_NO_LOCAL_MODEL_OR_WHEELS'),
      'next_steps':['Put a Piper .onnx model and its adjacent .onnx.json config in the model directory.',
        'If offline, put piper-tts and all required dependency .whl files in the wheel directory.',
        'Install from local wheels only with: python -m pip install --no-index --find-links TOOLS/voice_benchmark_stage37/wheels piper-tts',
        'Then run: python TOOLS/run_voice_benchmark_stage36.py --model TOOLS/voice_benchmark_stage37/models/YOUR_MODEL.onnx',
        'Do not treat eSpeak baseline as neural or as proof of emotional naturalness.']}
    out=root/'TOOLS/voice_benchmark_stage37/output/setup_doctor_stage37.json'; out.parent.mkdir(parents=True,exist_ok=True); out.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(result,ensure_ascii=False,indent=2)); return 0
if __name__=='__main__': raise SystemExit(main())
