extends Node3D

const PLAYER_SCRIPT = preload("res://scripts/player.gd")
const ZOMBIE_SCRIPT = preload("res://scripts/zombie.gd")
const AUDIO_DIRECTOR_SCRIPT = preload("res://scripts/audio_director.gd")

var player
var hud: CanvasLayer
var status_label: Label
var health_label: Label
var health_bar: ProgressBar
var critical_health_vignette: ColorRect
var critical_health_label: Label
var damage_flash_overlay: ColorRect
var damage_flash_timer: float = 0.0
var healing_feedback_label: Label
var healing_feedback_timer: float = 0.0
var healing_feedback_amount: int = 0
var last_observed_health: float = -1.0
var objective_label: Label
var kills: int = 0
var total_zombies: int = 6
var stage_number: int = 1
var finished: bool = false
var ended: bool = false
var ending_overlay: Control
var ambience_clock: float = 0.0
var audio_director: Node
var language: String = "fa"
var language_button: Button
var help_label: Label
var attack_button: Button
var dodge_button: Button
var intro_title_label: Label
var intro_story_label: Label
var intro_overlay: Control
var ending_title_label: Label
var ending_body_label: Label
var ending_restart_button: Button
var ending_is_victory: bool = false
var transition_story_label: Label

func _ready() -> void:
    randomize()
    stage_number = _load_saved_stage()
    total_zombies = 6 + (stage_number - 1) * 2
    _build_world()
    _spawn_player()
    _spawn_zombies()
    _spawn_captive_girl()
    _build_hud()
    audio_director = Node.new()
    audio_director.name = "AudioDirector"
    audio_director.set_script(AUDIO_DIRECTOR_SCRIPT)
    add_child(audio_director)
    update_hud()
    last_observed_health = player.health
    _show_intro_card()

func _build_world() -> void:
    var world_env := WorldEnvironment.new()
    var environment := Environment.new()
    environment.background_mode = Environment.BG_SKY
    environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    environment.ambient_light_color = Color(0.12, 0.15, 0.19)
    environment.ambient_light_energy = 0.48
    environment.reflected_light_source = Environment.REFLECTION_SOURCE_BG
    environment.sdfgi_enabled = false
    environment.tonemap_mode = Environment.TONE_MAPPER_FILMIC
    environment.fog_enabled = true
    environment.fog_light_color = Color(0.16, 0.19, 0.22)
    environment.fog_density = 0.035
    environment.fog_sky_affect = 0.35
    world_env.environment = environment
    add_child(world_env)

    var sun := DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-55, -25, 0)
    sun.light_energy = 0.48
    sun.shadow_enabled = true
    sun.directional_shadow_max_distance = 38.0
    sun.light_color = Color(0.56, 0.62, 0.75)
    add_child(sun)

    var ground := StaticBody3D.new()
    ground.name = "Ground"
    var ground_mesh := MeshInstance3D.new()
    var plane := PlaneMesh.new()
    plane.size = Vector2(70, 70)
    ground_mesh.mesh = plane
    var ground_mat := StandardMaterial3D.new()
    ground_mat.albedo_color = Color(0.09, 0.105, 0.09)
    ground_mat.roughness = 1.0
    ground_mesh.material_override = ground_mat
    ground.add_child(ground_mesh)
    var ground_collision := CollisionShape3D.new()
    var ground_shape := BoxShape3D.new()
    ground_shape.size = Vector3(70, 0.2, 70)
    ground_collision.shape = ground_shape
    ground_collision.position.y = -0.1
    ground.add_child(ground_collision)
    add_child(ground)

    # Temporary procedural gravestones; replace with art assets in a later stage.
    for i in range(22):
        var tomb := MeshInstance3D.new()
        var stone := BoxMesh.new()
        stone.size = Vector3(randf_range(0.62, 0.82), randf_range(0.8, 1.25), 0.22)
        tomb.mesh = stone
        tomb.position = Vector3(randf_range(-16, 16), stone.size.y / 2.0, randf_range(-15, 15))
        tomb.rotation_degrees.y = randf_range(-9.0, 9.0)
        if Vector2(tomb.position.x, tomb.position.z).length() < 4.5:
            tomb.position.x += 7.0
        var stone_mat := StandardMaterial3D.new()
        stone_mat.albedo_color = Color(randf_range(0.14, 0.22), randf_range(0.16, 0.23), randf_range(0.15, 0.21))
        stone_mat.roughness = 1.0
        stone_mat.metallic = 0.02
        tomb.material_override = stone_mat
        add_child(tomb)

    # Stage 9 atmosphere: cold ground haze lights and broken stone fragments.
    for i in range(9):
        var shard := MeshInstance3D.new()
        var shard_mesh := BoxMesh.new()
        shard_mesh.size = Vector3(randf_range(0.12, 0.32), randf_range(0.04, 0.09), randf_range(0.12, 0.28))
        shard.mesh = shard_mesh
        shard.position = Vector3(randf_range(-18, 18), 0.04, randf_range(-18, 18))
        var shard_mat := StandardMaterial3D.new()
        shard_mat.albedo_color = Color(0.12, 0.14, 0.13)
        shard_mat.roughness = 1.0
        shard.material_override = shard_mat
        add_child(shard)

    # Sparse dead grass clumps and wet-looking dark stones break up the flat ground.
    for i in range(72):
        var tuft := MeshInstance3D.new()
        var tuft_mesh := BoxMesh.new()
        tuft_mesh.size = Vector3(randf_range(0.025, 0.055), randf_range(0.12, 0.32), 0.025)
        tuft.mesh = tuft_mesh
        tuft.position = Vector3(randf_range(-24, 24), tuft_mesh.size.y / 2.0, randf_range(-24, 24))
        tuft.rotation_degrees.y = randf_range(0.0, 180.0)
        var grass_mat := StandardMaterial3D.new()
        grass_mat.albedo_color = Color(randf_range(0.055, 0.11), randf_range(0.075, 0.13), randf_range(0.06, 0.09))
        grass_mat.roughness = 1.0
        tuft.material_override = grass_mat
        add_child(tuft)

    # Stage 12: flattened reflective-looking puddles and scattered dark stones add ground breakup.
    var puddle_mat := StandardMaterial3D.new()
    puddle_mat.albedo_color = Color(0.055, 0.075, 0.075)
    puddle_mat.roughness = 0.24
    puddle_mat.metallic = 0.12
    for i in range(12):
        var puddle := MeshInstance3D.new()
        var puddle_mesh := CylinderMesh.new()
        puddle_mesh.top_radius = randf_range(0.28, 0.72)
        puddle_mesh.bottom_radius = puddle_mesh.top_radius
        puddle_mesh.height = 0.012
        puddle.mesh = puddle_mesh
        puddle.position = Vector3(randf_range(-22, 22), 0.018, randf_range(-22, 22))
        puddle.scale = Vector3(1.0, 1.0, randf_range(0.45, 0.8))
        puddle.rotation_degrees.y = randf_range(0.0, 180.0)
        puddle.material_override = puddle_mat
        add_child(puddle)

    var cold_light := OmniLight3D.new()
    cold_light.name = "MoonlitMist"
    cold_light.position = Vector3(-7, 2.2, -8)
    cold_light.light_color = Color(0.35, 0.48, 0.62)
    cold_light.light_energy = 0.8
    cold_light.omni_range = 11.0
    add_child(cold_light)

    var rim_light := OmniLight3D.new()
    rim_light.name = "ColdRimLight"
    rim_light.position = Vector3(8, 3.0, 5)
    rim_light.light_color = Color(0.28, 0.42, 0.58)
    rim_light.light_energy = 0.55
    rim_light.omni_range = 9.0
    add_child(rim_light)

func _spawn_player() -> void:
    player = CharacterBody3D.new()
    player.name = "Hero"
    player.set_script(PLAYER_SCRIPT)
    player.position = Vector3(0, 0.15, 0)
    add_child(player)
    player.main_ref = self

func _spawn_zombies() -> void:
    var positions := [
        Vector3(5, 0.1, -5), Vector3(-6, 0.1, -4),
        Vector3(8, 0.1, 3), Vector3(-8, 0.1, 4),
        Vector3(2, 0.1, -10), Vector3(-3, 0.1, 10)
    ]
    for i in range(total_zombies):
        var spawn_pos: Vector3
        if i < positions.size():
            spawn_pos = positions[i]
        else:
            var angle := TAU * float(i) / float(total_zombies)
            var radius := 8.0 + float(stage_number - 1) * 0.7
            spawn_pos = Vector3(cos(angle) * radius, 0.1, sin(angle) * radius)
        var enemy := CharacterBody3D.new()
        enemy.set_script(ZOMBIE_SCRIPT)
        enemy.position = spawn_pos
        # Every third stage introduces a slower, tougher brute to change the combat rhythm.
        if stage_number % 3 == 0 and i == 0:
            enemy.set("flanking_enabled", false)
            enemy.set("is_brute", true)
            enemy.set("max_health", 150.0)
            enemy.set("move_speed", 1.05)
            enemy.set("attack_damage", 11.0)
            enemy.scale = Vector3(1.28, 1.28, 1.28)
        add_child(enemy)

func _build_hud() -> void:
    hud = CanvasLayer.new()
    add_child(hud)

    # Stage 45: subtle pulsing warning when the hero is critically wounded.
    critical_health_vignette = ColorRect.new()
    critical_health_vignette.name = "CriticalHealthVignette"
    critical_health_vignette.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    critical_health_vignette.color = Color(0.62, 0.015, 0.02, 0.0)
    critical_health_vignette.mouse_filter = Control.MOUSE_FILTER_IGNORE
    hud.add_child(critical_health_vignette)

    critical_health_label = Label.new()
    critical_health_label.name = "CriticalHealthWarning"
    critical_health_label.set_anchors_preset(Control.PRESET_CENTER_TOP)
    critical_health_label.position = Vector2(-170, 22)
    critical_health_label.size = Vector2(340, 42)
    critical_health_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    critical_health_label.add_theme_font_size_override("font_size", 24)
    critical_health_label.add_theme_color_override("font_color", Color(1.0, 0.24, 0.20, 1.0))
    critical_health_label.text = "سلامت بحرانی"
    critical_health_label.visible = false
    critical_health_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
    hud.add_child(critical_health_label)

    # Stage 47: briefly confirm the exact amount restored by a first-aid pickup.
    healing_feedback_label = Label.new()
    healing_feedback_label.name = "HealingFeedback"
    healing_feedback_label.set_anchors_preset(Control.PRESET_CENTER_TOP)
    healing_feedback_label.position = Vector2(-180, 66)
    healing_feedback_label.size = Vector2(360, 38)
    healing_feedback_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    healing_feedback_label.add_theme_font_size_override("font_size", 23)
    healing_feedback_label.add_theme_color_override("font_color", Color(0.42, 1.0, 0.57, 1.0))
    healing_feedback_label.text = ""
    healing_feedback_label.visible = false
    healing_feedback_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
    hud.add_child(healing_feedback_label)

    var panel := ColorRect.new()
    panel.position = Vector2(16, 14)
    panel.size = Vector2(390, 136)
    panel.color = Color(0.015, 0.02, 0.025, 0.82)
    hud.add_child(panel)

    health_label = Label.new()
    health_label.position = Vector2(14, 5)
    health_label.add_theme_font_size_override("font_size", 22)
    panel.add_child(health_label)

    health_bar = ProgressBar.new()
    health_bar.name = "HealthBar"
    health_bar.position = Vector2(14, 34)
    health_bar.size = Vector2(350, 12)
    health_bar.min_value = 0.0
    health_bar.max_value = 100.0
    health_bar.show_percentage = false
    var health_bg := StyleBoxFlat.new()
    health_bg.bg_color = Color(0.10, 0.12, 0.13, 1.0)
    health_bg.corner_radius_top_left = 3
    health_bg.corner_radius_top_right = 3
    health_bg.corner_radius_bottom_left = 3
    health_bg.corner_radius_bottom_right = 3
    health_bar.add_theme_stylebox_override("background", health_bg)
    var health_fill := StyleBoxFlat.new()
    health_fill.bg_color = Color(0.18, 0.78, 0.32, 1.0)
    health_fill.corner_radius_top_left = 3
    health_fill.corner_radius_top_right = 3
    health_fill.corner_radius_bottom_left = 3
    health_fill.corner_radius_bottom_right = 3
    health_bar.add_theme_stylebox_override("fill", health_fill)
    panel.add_child(health_bar)

    objective_label = Label.new()
    objective_label.position = Vector2(14, 55)
    objective_label.add_theme_font_size_override("font_size", 18)
    panel.add_child(objective_label)

    status_label = Label.new()
    status_label.position = Vector2(14, 88)
    status_label.add_theme_font_size_override("font_size", 16)
    status_label.add_theme_color_override("font_color", Color(0.78, 0.82, 0.82))
    panel.add_child(status_label)

    help_label = Label.new()
    help_label.position = Vector2(18, 142)
    help_label.add_theme_font_size_override("font_size", 16)
    hud.add_child(help_label)

    language_button = Button.new()
    language_button.text = "English"
    language_button.position = Vector2(16, 190)
    language_button.size = Vector2(130, 48)
    language_button.pressed.connect(_toggle_language)
    hud.add_child(language_button)

    _make_direction_button("↑", Vector2(92, 555), Vector2(0, -1))
    _make_direction_button("↓", Vector2(92, 635), Vector2(0, 1))
    _make_direction_button("←", Vector2(12, 595), Vector2(-1, 0))
    _make_direction_button("→", Vector2(172, 595), Vector2(1, 0))

    attack_button = Button.new()
    attack_button.size = Vector2(190, 78)
    attack_button.anchor_left = 1.0
    attack_button.anchor_right = 1.0
    attack_button.anchor_top = 1.0
    attack_button.anchor_bottom = 1.0
    attack_button.offset_left = -220.0
    attack_button.offset_right = -30.0
    attack_button.offset_top = -120.0
    attack_button.offset_bottom = -42.0
    attack_button.add_theme_font_size_override("font_size", 20)
    attack_button.pressed.connect(_on_attack_pressed)
    hud.add_child(attack_button)

    dodge_button = Button.new()
    dodge_button.size = Vector2(150, 58)
    dodge_button.anchor_left = 1.0
    dodge_button.anchor_right = 1.0
    dodge_button.anchor_top = 1.0
    dodge_button.anchor_bottom = 1.0
    dodge_button.offset_left = -390.0
    dodge_button.offset_right = -235.0
    dodge_button.offset_top = -105.0
    dodge_button.offset_bottom = -47.0
    dodge_button.add_theme_font_size_override("font_size", 18)
    dodge_button.pressed.connect(_on_dodge_pressed)
    hud.add_child(dodge_button)

    # Stage 46: brief, non-blocking red screen flash when the hero takes damage.
    damage_flash_overlay = ColorRect.new()
    damage_flash_overlay.name = "DamageHitFlash"
    damage_flash_overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    damage_flash_overlay.color = Color(0.78, 0.015, 0.02, 0.0)
    damage_flash_overlay.mouse_filter = Control.MOUSE_FILTER_IGNORE
    hud.add_child(damage_flash_overlay)

func _make_direction_button(button_text: String, button_position: Vector2, direction: Vector2) -> void:
    var move_btn := Button.new()
    move_btn.text = button_text
    move_btn.position = button_position
    move_btn.size = Vector2(68, 68)
    move_btn.anchor_top = 1.0
    move_btn.anchor_bottom = 1.0
    move_btn.offset_top = button_position.y - 720.0
    move_btn.offset_bottom = button_position.y - 652.0
    move_btn.add_theme_font_size_override("font_size", 26)
    move_btn.button_down.connect(func():
        if is_instance_valid(player):
            player.set_mobile_move(direction)
    )
    move_btn.button_up.connect(func():
        if is_instance_valid(player):
            player.set_mobile_move(Vector2.ZERO)
    )
    hud.add_child(move_btn)

func play_sfx(sound_id: String) -> void:
    if is_instance_valid(audio_director) and audio_director.has_method("play_sfx"):
        audio_director.play_sfx(sound_id)

func _on_attack_pressed() -> void:
    if is_instance_valid(player) and not ended:
        player.request_attack()

func _on_dodge_pressed() -> void:
    if is_instance_valid(player) and not ended:
        player.request_dodge()

func update_hud() -> void:
    if not is_instance_valid(hud) or not is_instance_valid(player):
        return
    health_label.text = ("Health: %d / %d" if language == "en" else "سلامتی: %d از %d") % [int(player.health), int(player.max_health)]
    health_bar.max_value = player.max_health
    health_bar.value = player.health
    var health_ratio := clampf(player.health / maxf(1.0, player.max_health), 0.0, 1.0)
    var health_fill := health_bar.get_theme_stylebox("fill").duplicate() as StyleBoxFlat
    health_fill.bg_color = Color(0.90, 0.18, 0.14, 1.0).lerp(Color(0.18, 0.78, 0.32, 1.0), health_ratio)
    health_bar.add_theme_stylebox_override("fill", health_fill)
    objective_label.text = ("Objective: Clear the graveyard (%d/%d)" if language == "en" else "هدف: پاکسازی قبرستان (%d/%d)") % [kills, total_zombies]
    help_label.text = "Move: WASD / Arrows   Attack: SPACE   Dodge: SHIFT" if language == "en" else "حرکت: جهت‌ها   حمله: فاصله   جاخالی: Shift"
    attack_button.text = "Axe Attack" if language == "en" else "ضربه با تبر"
    dodge_button.text = "Dodge" if language == "en" else "جاخالی"
    var dodge_ready := player.dodge_cooldown <= 0.0 and player.health > 0.0
    dodge_button.disabled = not dodge_ready
    var dodge_hint := ("Dodge: Ready" if dodge_ready else "Dodge: %ds" % int(ceil(player.dodge_cooldown))) if language == "en" else ("جاخالی: آماده" if dodge_ready else "جاخالی: %d ثانیه" % int(ceil(player.dodge_cooldown)))
    help_label.text += "   |   " + dodge_hint
    if not ended and not finished:
        status_label.text = ("Chapter %d — Abandoned Graveyard" if language == "en" else "مرحله %d — گورستان متروکه") % stage_number
    elif finished and not ended:
        objective_label.text = "All undead eliminated; find the girl!" if language == "en" else "همهٔ زامبی‌ها کشته شدند؛ دختر را پیدا کن!"
        status_label.text = "Approach the red marker to rescue her" if language == "en" else "به نشانگر قرمز نزدیک شو تا او را نجات بدهی"
    elif ended and not ending_is_victory:
        status_label.text = "You were defeated — press restart" if language == "en" else "شکست خوردی — برای شروع دوباره دکمه را بزن"

func _toggle_language() -> void:
    language = "en" if language == "fa" else "fa"
    if is_instance_valid(language_button):
        language_button.text = "فارسی" if language == "en" else "English"
    update_hud()
    _refresh_story_cards()

func on_zombie_killed() -> void:
    kills += 1
    update_hud()
    if kills >= total_zombies and not finished:
        finished = true
        objective_label.text = "All undead eliminated; find the girl!" if language == "en" else "همهٔ زامبی‌ها کشته شدند؛ دختر را پیدا کن!"
        status_label.text = "Approach the red marker to rescue her" if language == "en" else "به نشانگر قرمز نزدیک شو تا او را نجات بدهی"

func game_over() -> void:
    if ended:
        return
    ended = true
    status_label.text = "You were defeated — press restart" if language == "en" else "شکست خوردی — برای شروع دوباره دکمه را بزن"
    if is_instance_valid(player):
        player.set_physics_process(false)
    for enemy in get_tree().get_nodes_in_group("zombies"):
        if is_instance_valid(enemy):
            enemy.set_physics_process(false)
    _show_end_card("شکست خوردی", "این بار با دقت بیشتری مبارزه کن.")

func _spawn_captive_girl() -> void:
    # Placeholder character and red beacon: not final character art.
    var girl := Node3D.new()
    girl.name = "CaptiveGirl"
    girl.position = Vector3(0, 0, -17)
    var torso := MeshInstance3D.new()
    var torso_mesh := CapsuleMesh.new()
    torso_mesh.radius = 0.28
    torso_mesh.height = 1.25
    torso.mesh = torso_mesh
    torso.position.y = 0.63
    var torso_mat := StandardMaterial3D.new()
    torso_mat.albedo_color = Color(0.22, 0.28, 0.42)
    torso.material_override = torso_mat
    girl.add_child(torso)
    var head := MeshInstance3D.new()
    var head_mesh := SphereMesh.new()
    head_mesh.radius = 0.2
    head_mesh.height = 0.4
    head.mesh = head_mesh
    head.position.y = 1.42
    var head_mat := StandardMaterial3D.new()
    head_mat.albedo_color = Color(0.62, 0.47, 0.38)
    head.material_override = head_mat
    girl.add_child(head)
    var beacon := OmniLight3D.new()
    beacon.name = "RescueBeacon"
    beacon.position.y = 2.2
    beacon.light_color = Color(0.85, 0.08, 0.04)
    beacon.light_energy = 1.5
    beacon.omni_range = 5.0
    girl.add_child(beacon)
    # Stage 15: low-cost ritual sigil rings and emissive marks around the captive.
    for ring_index in range(3):
        var ring := MeshInstance3D.new()
        var ring_mesh := TorusMesh.new()
        ring_mesh.inner_radius = 0.035
        ring_mesh.outer_radius = 0.055
        ring_mesh.rings = 24
        ring_mesh.ring_segments = 8
        ring.name = "RitualRing%d" % ring_index
        ring.mesh = ring_mesh
        ring.position = Vector3(0, 0.035 + ring_index * 0.008, 0)
        ring.scale = Vector3(1.2 + ring_index * 0.48, 1.0, 1.2 + ring_index * 0.48)
        var ring_mat := StandardMaterial3D.new()
        ring_mat.albedo_color = Color(0.42, 0.035, 0.025)
        ring_mat.emission_enabled = true
        ring_mat.emission = Color(0.32, 0.018, 0.012)
        ring_mat.roughness = 0.38
        ring.material_override = ring_mat
        girl.add_child(ring)
    # Stage 17: small emissive embers orbit above the sigil for depth without texture assets.
    for ember_index in range(8):
        var ember := MeshInstance3D.new()
        ember.name = "RitualEmber%d" % ember_index
        var ember_mesh := SphereMesh.new()
        ember_mesh.radius = 0.035
        ember_mesh.height = 0.07
        ember.mesh = ember_mesh
        var angle := TAU * float(ember_index) / 8.0
        ember.position = Vector3(cos(angle) * 1.15, 0.14 + float(ember_index % 3) * 0.06, sin(angle) * 1.15)
        var ember_mat := StandardMaterial3D.new()
        ember_mat.albedo_color = Color(0.9, 0.12, 0.045)
        ember_mat.emission_enabled = true
        ember_mat.emission = Color(0.95, 0.055, 0.02)
        ember_mat.emission_energy_multiplier = 1.1
        ember_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
        ember.material_override = ember_mat
        girl.add_child(ember)
    add_child(girl)

func _show_intro_card() -> void:
    if is_instance_valid(audio_director):
        audio_director.play_voice_sequence(["intro_girl_01", "intro_masked_01", "intro_hero_01"])
    intro_overlay = ColorRect.new()
    intro_overlay.name = "IntroCard"
    intro_overlay.color = Color(0.01, 0.012, 0.018, 0.94)
    intro_overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    intro_overlay.mouse_filter = Control.MOUSE_FILTER_IGNORE
    hud.add_child(intro_overlay)
    intro_title_label = Label.new()
    intro_title_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    intro_title_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    intro_title_label.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    intro_title_label.offset_top = -40
    intro_title_label.add_theme_font_size_override("font_size", 42)
    intro_title_label.add_theme_color_override("font_color", Color(0.8, 0.83, 0.85))
    intro_overlay.add_child(intro_title_label)
    intro_story_label = Label.new()
    intro_story_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    intro_story_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    intro_story_label.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    intro_story_label.offset_top = 65
    intro_story_label.add_theme_font_size_override("font_size", 22)
    intro_story_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    intro_story_label.offset_left = 36.0
    intro_story_label.offset_right = -36.0
    intro_story_label.offset_bottom = -28.0
    intro_story_label.add_theme_color_override("font_color", Color(0.72, 0.72, 0.72))
    intro_overlay.add_child(intro_story_label)
    _refresh_story_cards()
    var tween := create_tween()
    tween.tween_interval(3.5)
    tween.tween_property(intro_overlay, "modulate:a", 0.0, 1.0)
    tween.tween_callback(intro_overlay.queue_free)

func _refresh_story_cards() -> void:
    if is_instance_valid(intro_title_label):
        intro_title_label.text = "Last Rescue" if language == "en" else "آخرین نجات"
    if is_instance_valid(intro_story_label):
        intro_story_label.text = "00:13 — Rain breathes over the graveyard.\nGirl: ‘Please… can you hear my heartbeat? I’m still alive!’\nMasked Man: ‘Your heart will be the last thing to stop.’\nHero: ‘Get away from her! If she’s alive, I’m taking her out.’\nThe graves split open. Take your axe, fight through the dead, and reach the girl before the ritual is complete." if language == "en" else "ساعت ۰۰:۱۳؛ گورستان زیر باران نفس می‌کشد.\nدختر: «خواهش می‌کنم… صدای قلبم رو می‌شنوی؟ من هنوز زنده‌ام!»\nمرد نقاب‌دار: «قلبت آخرین چیزی‌ست که خاموش می‌شود.»\nقهرمان: «ازش فاصله بگیر! اگه هنوز زنده‌ست، نجاتش می‌دم.»\nخاک قبرها می‌شکافد؛ تبر را بردار، راهت را باز کن و پیش از کامل‌شدن آیین به دختر برس."
    if is_instance_valid(ending_title_label):
        ending_title_label.text = ("Rescue Successful" if language == "en" else "نجات موفقیت‌آمیز") if ending_is_victory else ("You Were Defeated" if language == "en" else "شکست خوردی")
    if is_instance_valid(ending_body_label):
        ending_body_label.text = _english_rescue_dialogue() if language == "en" and ending_is_victory else (("Fight more carefully next time." if language == "en" else "این بار با دقت بیشتری مبارزه کن.") if not ending_is_victory else _persian_rescue_dialogue())
    if is_instance_valid(ending_restart_button):
        ending_restart_button.text = ("Next Chapter" if language == "en" else "رفتن به مرحلهٔ بعد") if ending_is_victory else ("Restart" if language == "en" else "شروع دوباره")
    if is_instance_valid(transition_story_label):
        transition_story_label.text = _stage_transition_text()

func _persian_rescue_dialogue() -> String:
    if stage_number == 9:
        return "قهرمان: «این بایگانی پر از پرونده‌های سوخته‌ست.»\nدختر: «این یکی دربارهٔ من نیست… دربارهٔ توئه. اسم تو قبل از تولدت ثبت شده.»\nقهرمان: «پس منو از اول برای این روز آماده کرده بودن؟»\nمرد نقاب‌دار: «بالاخره داری سؤال درست رو می‌پرسی.»"
    if stage_number == 10:
        return "دختر: «این قلب زنده‌ست… هر بار می‌تپه، زامبی‌ها بیدار می‌شن.»\nقهرمان: «با تبر نابودش می‌کنم. تو از دروازه دور شو!»\nمرد نقاب‌دار: «اگر قلب رو بزنی، حقیقتِ تو هم می‌میره.»\nدختر: «بهش گوش نده! این بار انتخاب با خودمونه.»"
    if stage_number == 11:
        return "دختر: «این صداها از دیوارها میان… دارن اسم‌هامون رو می‌خونن.»\nقهرمان: «به آوازشون گوش نده؛ دارن ما رو به سمت خودشون می‌کشن.»\nمرد نقاب‌دار: «هر صدایی که می‌شنوی، خاطره‌ایه که دفنش کردی.»\nدختر: «پس این بار با صدای خودمون جواب می‌دیم!»"
    if stage_number == 12:
        return "صدای بی‌سیم: «اگر کسی این پیام رو می‌شنوه، برج مخابرات آخرین نقطهٔ امنه.»\nقهرمان: «پیام زنده‌ست؛ هنوز کسی اون بالا مونده.»\nدختر: «یا چیزی می‌خواد ما رو به برج بکشونه…»\nمرد نقاب‌دار: «بالاخره به آخرین دروازه نزدیک شدی.»"
    if stage_number == 7:
        return "دختر: «این اتاقک‌ها… اسم قربانی‌ها رو روی دیوار نوشتن.»\nقهرمان: «اسم‌ها رو بخون. شاید بفهمیم چه کسی این فاجعه رو شروع کرد.»\nدختر: «اسم خودم اینجاست… ولی تاریخش برای صد سال پیشه!»\nمرد نقاب‌دار: «حافظه‌ات داره برمی‌گرده؛ نباید می‌ذاشتم زنده بمونی.»"
    if stage_number == 8:
        return "قهرمان: «درِ فولادی پشت این علامت‌هاست. باید بازش کنیم.»\nدختر: «نه! هر بار که نزدیکش می‌شم، صدای اون توی سرم بلندتر می‌شه.»\nمرد نقاب‌دار: «پشت این در، حقیقتی هست که خودت از همه بیشتر ازش می‌ترسی.»\nصدای بی‌سیم: «هشدار؛ منبع آلودگی در حال بیدار شدن است.»"
    if stage_number == 2:
        return "دختر: «این قبرستان فقط ورودی بود؛ راهرویی زیر کلیسا هست.»\nقهرمان: «پس راه می‌افتیم. این بار غافلگیرشون نمی‌شیم.»\nدختر: «مواظب باش… بعضی از اون‌ها هنوز آدم بودن.»\nصدای بی‌سیم: «واحدهای باقی‌مانده، به سردابه نزدیک نشوید!»"
    if stage_number >= 3:
        return "دختر: «اون غول… قبلاً نگهبان همین‌جا بوده.»\nقهرمان: «هر چی بوده، دیگه اجازه نمی‌دم دنبالمون بیاد.»\nصدای بی‌سیم: «تیم پشتیبانی از دست رفت. به هیچ‌کس اعتماد نکنید.»\nاز دل سردابه، سه ضربهٔ سنگین به در می‌خورد."
    return "دختر: «فکر کردم دیگه هیچ‌وقت نور صبح رو نمی‌بینم…»\nقهرمان: «می‌تونی راه بری؟ باید از اینجا بریم.»\nدختر: «اون‌ها فقط منو نمی‌خواستن… اسم تو رو هم می‌دونستن.»\nصدایی از پشت مقبره: «این فقط آغاز بود… دفعهٔ بعد، قبرها همه باز می‌شن.»"

func _english_rescue_dialogue() -> String:
    if stage_number == 9:
        return "Hero: ‘This archive is full of burned files.’\nGirl: ‘This one isn’t about me… it’s about you. Your name was registered before you were born.’\nHero: ‘So someone prepared me for this from the beginning?’\nMasked Man: ‘At last, you’re asking the right question.’"
    if stage_number == 10:
        return "Girl: ‘This heart is alive… every beat wakes the dead.’\nHero: ‘I’ll destroy it with my axe. Get away from the gate!’\nMasked Man: ‘If you strike the heart, your truth dies with it.’\nGirl: ‘Don’t listen! This time, we choose our own fate.’"
    if stage_number == 11:
        return "Girl: ‘Those voices are coming from the walls… they’re reading our names.’\nHero: ‘Don’t follow their song. They’re pulling us toward them.’\nMasked Man: ‘Every voice is a memory you buried.’\nGirl: ‘Then we answer in our own voices!’"
    if stage_number == 12:
        return "Radio: ‘If anyone can hear this, the relay tower is the last safe point.’\nHero: ‘The signal is live. Someone may still be up there.’\nGirl: ‘Or something wants us to climb into a trap…’\nMasked Man: ‘At last, you approach the final gate.’"
    if stage_number == 7:
        return "Girl: ‘These cells… the victims’ names are written on the walls.’\nHero: ‘Read them. Maybe we can learn who started this.’\nGirl: ‘My name is here… but the date is a hundred years old!’\nMasked Man: ‘Your memories are returning. I should never have let you live.’"
    if stage_number == 8:
        return "Hero: ‘There’s a steel door behind these markings. We have to open it.’\nGirl: ‘No! Whenever I get close, his voice gets louder inside my head.’\nMasked Man: ‘Behind this door is the truth you fear most.’\nRadio: ‘Warning. The infection source is awakening.’"
    if stage_number == 2:
        return "Girl: ‘This graveyard was only an entrance. There’s a passage beneath the church.’\nHero: ‘Then we move. They won’t catch us off guard again.’\nGirl: ‘Be careful… some of them used to be human.’\nRadio: ‘All remaining units, stay away from the catacombs!’"
    if stage_number >= 3:
        return "Girl: ‘That brute… he used to guard this place.’\nHero: ‘Whatever he was, he won’t follow us again.’\nRadio: ‘Support team lost. Trust no one.’\nThree heavy blows echo from the catacomb door."
    return "Girl: ‘I thought I’d never see the morning light again…’\nHero: ‘Can you walk? We have to get out of here.’\nGirl: ‘They didn’t just want me… they knew your name, too.’\nA voice behind the tomb whispers: ‘This is only the beginning. Next time, every grave will open.’"

func _stage_transition_text() -> String:
    var chapter_title := "راهروی سردابه"
    var chapter_dialogue := "قهرمان: «هر قبر باز یعنی یک دشمن کمتر که غافلگیرمون کنه.»\nدختر: «نه… گوش کن. صدای قدم‌ها از زیر زمین میاد.»\nصدای ناشناس: «تبرت رو نگه دار، نجات‌دهنده. اینجا تازه شروعشه.»"
    if stage_number == 4:
        chapter_title = "محراب زیرزمینی"
        chapter_dialogue = "دختر: «این علامت‌ها رو دیوار… همون نشونی‌ان که روی دست اون مرد بود.»\nقهرمان: «پس اینجا مرکز ماجراست. پشت سرم بمون.»\nمرد نقاب‌دار: «بالاخره رسیدی. حالا می‌فهمی چرا انتخابت کردم.»"
    elif stage_number == 5:
        chapter_title = "تونل قربانیان"
        chapter_dialogue = "قهرمان: «رد خون تا انتهای تونل می‌ره.»\nدختر: «اگه صدای کسی رو شنیدی، عجله نکن… شاید دیگه انسان نباشه.»\nصدای بی‌سیم: «اگر پیام رو می‌شنوید، به سطح برنگردید؛ محوطه سقوط کرده.»"
    elif stage_number == 7:
        chapter_title = "سلول‌های فراموش‌شده"
        chapter_dialogue = "دختر: «اسم من روی دیواره… ولی این تاریخ مال صد سال پیشه!»\nقهرمان: «پس این فقط یه آدم‌ربایی نیست. باید بفهمیم تو کی هستی.»\nمرد نقاب‌دار: «هر دری که باز می‌کنی، بخشی از حافظه‌ات رو پس می‌گیری.»"
    elif stage_number == 9:
        chapter_title = "بایگانی خاکستر"
        chapter_dialogue = "قهرمان: «پرونده‌ها سوختن، اما اسم من هنوز اینجاست.»\nدختر: «این تاریخ قبل از تولد توئه. یکی همه‌چیز رو از قبل چیده.»\nمرد نقاب‌دار: «حالا می‌فهمی چرا هیچ‌وقت نتونستی فرار کنی.»"
    elif stage_number == 10:
        chapter_title = "قلب زنده"
        chapter_dialogue = "دختر: «هر ضربانش مرده‌ها رو بیدار می‌کنه.»\nقهرمان: «این بار فرار نمی‌کنیم؛ به قلب آلودگی پایان می‌دیم.»\nمرد نقاب‌دار: «پس انتخاب کن: حقیقت یا نجات.»"
    elif stage_number == 11:
        chapter_title = "هم‌سرایان توخالی"
        chapter_dialogue = "دختر: «صداها اسم‌هامون رو می‌خونن.»\nقهرمان: «اونا صدا نیستن؛ تله‌ان. از دیوارها فاصله بگیر.»\nمرد نقاب‌دار: «برای عبور باید با ترس‌هات هم‌صدا بشی.»"
    elif stage_number == 12:
        chapter_title = "آخرین پیام"
        chapter_dialogue = "بی‌سیم: «برج مخابرات آخرین نقطهٔ امنه.»\nقهرمان: «این پیام تازه‌ست. حرکت کن!»\nدختر: «اگه تله باشه چی؟»\nقهرمان: «این بار تصمیم رو با هم می‌گیریم.»"
    elif stage_number == 8:
        chapter_title = "دروازهٔ آهنین"
        chapter_dialogue = "قهرمان: «در رو باز می‌کنم. پشتش هر چی باشه، با هم روبه‌رو می‌شیم.»\nدختر: «اگه اون صدا منو کنترل کرد… قول بده جلوش رو بگیری.»\nصدای بی‌سیم: «هشدار؛ منبع آلودگی در حال بیدار شدن است.»"
    elif stage_number >= 6:
        chapter_title = "قلب آلودگی"
        chapter_dialogue = "دختر: «صداش رو می‌شنوم… انگار از توی سرم حرف می‌زنه.»\nقهرمان: «به صداش گوش نده. تا وقتی من اینجام، تنها نیستی.»\nمرد نقاب‌دار: «هر بار که نجاتش می‌دی، یک قدم به من نزدیک‌تر می‌شی.»"
    if language == "en":
        var english_title := "The Catacomb Passage"
        var english_dialogue := "Hero: ‘Every open grave means one less enemy can surprise us.’\nGirl: ‘No… listen. The footsteps are coming from underground.’\nUnknown voice: ‘Keep your axe ready, rescuer. This is only the beginning.’"
        if stage_number == 4:
            english_title = "The Underground Altar"
            english_dialogue = "Girl: ‘Those marks on the wall… they match the symbol on that man’s hand.’\nHero: ‘Then this is the heart of it. Stay behind me.’\nMasked Man: ‘You finally made it. Now you’ll learn why I chose you.’"
        elif stage_number == 5:
            english_title = "The Sacrifice Tunnels"
            english_dialogue = "Hero: ‘The blood trail leads to the end of the tunnel.’\nGirl: ‘If you hear someone, don’t rush in… they may no longer be human.’\nRadio: ‘If you can hear this, do not return to the surface. The compound has fallen.’"
        elif stage_number == 7:
            english_title = "The Forgotten Cells"
            english_dialogue = "Girl: ‘My name is on the wall… but this date is a hundred years old!’\nHero: ‘Then this is more than a kidnapping. We need to learn who you are.’\nMasked Man: ‘Every door you open returns another piece of your memory.’"
        elif stage_number == 9:
            english_title = "The Ash Archive"
            english_dialogue = "Hero: ‘The files burned, but my name is still here.’\nGirl: ‘This date is before you were born. Someone planned everything.’\nMasked Man: ‘Now you understand why you could never escape.’"
        elif stage_number == 10:
            english_title = "The Living Heart"
            english_dialogue = "Girl: ‘Every beat wakes the dead.’\nHero: ‘We won’t run this time. We end the infection here.’\nMasked Man: ‘Then choose: the truth or her life.’"
        elif stage_number == 11:
            english_title = "The Hollow Choir"
            english_dialogue = "Girl: ‘Those voices are coming from the walls… they’re reading our names.’\nHero: ‘Don’t follow their song. They’re pulling us toward them.’\nMasked Man: ‘Every voice is a memory you buried.’\nGirl: ‘Then we answer in our own voices!’"
        elif stage_number == 12:
            english_title = "The Last Signal"
            english_dialogue = "Radio: ‘The relay tower is the last safe point.’\nHero: ‘The signal is live. Someone may still be up there.’\nGirl: ‘Or something wants us to walk into a trap…’\nMasked Man: ‘At last, you approach the final gate.’"
        elif stage_number == 8:
            english_title = "The Iron Gate"
            english_dialogue = "Hero: ‘I’m opening it. Whatever is behind it, we face it together.’\nGirl: ‘If that voice takes control of me… promise you’ll stop it.’\nRadio: ‘Warning. The infection source is awakening.’"
        elif stage_number >= 6:
            english_title = "The Heart of the Infection"
            english_dialogue = "Girl: ‘I can hear it… it’s speaking inside my head.’\nHero: ‘Don’t listen. As long as I’m here, you’re not alone.’\nMasked Man: ‘Every time you save her, you take one step closer to me.’"
        return "Chapter %d — %s\n%s" % [stage_number, english_title, english_dialogue]
    return "مرحله %d — %s\n%s" % [stage_number, chapter_title, chapter_dialogue]

func _voice_cue(base_cue: String) -> String:
    return base_cue + "_en" if language == "en" else base_cue

func _process(delta: float) -> void:
    ambience_clock += delta
    var captive := get_node_or_null("CaptiveGirl")
    if captive:
        for ritual_mark in captive.get_children():
            if ritual_mark is MeshInstance3D:
                if ritual_mark.name.begins_with("RitualRing"):
                    var ritual_material := ritual_mark.material_override as StandardMaterial3D
                    if ritual_material:
                        ritual_material.emission_energy_multiplier = 0.65 + 0.45 * (0.5 + 0.5 * sin(ambience_clock * 2.4 + ritual_mark.position.x))
                elif ritual_mark.name.begins_with("RitualEmber"):
                    ritual_mark.position.y = 0.12 + 0.07 * (0.5 + 0.5 * sin(ambience_clock * 2.1 + ritual_mark.position.x * 2.0))
                    ritual_mark.rotation.y += delta * 0.7
        var beacon := captive.get_node_or_null("RescueBeacon")
        if beacon is OmniLight3D:
            beacon.light_energy = 1.0 + 0.45 * (0.5 + 0.5 * sin(ambience_clock * 3.1))
    if not is_instance_valid(player):
        return
    update_hud()
    # Stage 46: detect actual health loss, then fade a short red hit flash.
    if last_observed_health < 0.0:
        last_observed_health = player.health
    elif player.health < last_observed_health:
        damage_flash_timer = 0.24
        last_observed_health = player.health
    elif player.health > last_observed_health:
        healing_feedback_amount = int(round(player.health - last_observed_health))
        healing_feedback_timer = 1.35
        last_observed_health = player.health
    else:
        last_observed_health = player.health
    damage_flash_timer = maxf(0.0, damage_flash_timer - delta)
    healing_feedback_timer = maxf(0.0, healing_feedback_timer - delta)
    if is_instance_valid(healing_feedback_label):
        healing_feedback_label.visible = healing_feedback_timer > 0.0
        healing_feedback_label.text = ("+%d HP RESTORED" if language == "en" else "+%d سلامتی بازیابی شد") % healing_feedback_amount
        healing_feedback_label.modulate = Color(1.0, 1.0, 1.0, minf(1.0, healing_feedback_timer / 0.35))
    if is_instance_valid(damage_flash_overlay):
        var hit_alpha := 0.28 * (damage_flash_timer / 0.24) if damage_flash_timer > 0.0 else 0.0
        damage_flash_overlay.color = Color(0.78, 0.015, 0.02, hit_alpha)
    var health_ratio := clampf(player.health / maxf(1.0, player.max_health), 0.0, 1.0)
    var critical := health_ratio > 0.0 and health_ratio <= 0.30 and not ended
    if is_instance_valid(critical_health_vignette):
        var pulse := 0.5 + 0.5 * sin(ambience_clock * 5.0)
        critical_health_vignette.color = Color(0.62, 0.015, 0.02, (0.055 + pulse * 0.10) if critical else 0.0)
    if is_instance_valid(critical_health_label):
        critical_health_label.visible = critical
        critical_health_label.text = "CRITICAL HEALTH" if language == "en" else "سلامت بحرانی"
        critical_health_label.modulate = Color(1.0, 1.0, 1.0, 0.72 + 0.28 * (0.5 + 0.5 * sin(ambience_clock * 5.0))) if critical else Color.WHITE
    if finished and not ended:
        var girl := get_node_or_null("CaptiveGirl")
        if girl and player.global_position.distance_to(girl.global_position) < 2.5:
            ended = true
            objective_label.text = "Girl rescued!" if language == "en" else "دختر نجات پیدا کرد!"
            status_label.text = ("Chapter %d complete" % stage_number) if language == "en" else ("پایان مرحلهٔ %d" % stage_number)
            if is_instance_valid(player):
                player.set_physics_process(false)
            for enemy in get_tree().get_nodes_in_group("zombies"):
                if is_instance_valid(enemy):
                    enemy.set_physics_process(false)
            var beacon := girl.get_node_or_null("RescueBeacon")
            if beacon is OmniLight3D:
                beacon.light_energy = 0.0
            var rescue_dialogue := _persian_rescue_dialogue()
            if is_instance_valid(audio_director):
                if stage_number == 1:
                    audio_director.play_voice_sequence(["rescue_girl_01", "rescue_hero_01", "rescue_girl_02", "masked_tease_01"])
                elif stage_number == 2:
                    audio_director.play_voice_sequence(["stage2_girl_01", "stage2_hero_01", "stage2_girl_02", "radio_stage2_01"])
                elif stage_number == 7:
                    audio_director.play_voice_sequence(["stage7_girl_01", "stage7_hero_01", "stage7_girl_02", "stage7_masked_01"])
                elif stage_number == 8:
                    audio_director.play_voice_sequence(["stage8_hero_01", "stage8_girl_01", "stage8_masked_01", "radio_stage8_01"])
                elif stage_number == 9:
                    audio_director.play_voice_sequence([_voice_cue("stage9_hero_01"), _voice_cue("stage9_girl_01"), _voice_cue("stage9_hero_02"), _voice_cue("stage9_masked_01")])
                elif stage_number == 10:
                    audio_director.play_voice_sequence([_voice_cue("stage10_girl_01"), _voice_cue("stage10_hero_01"), _voice_cue("stage10_masked_01"), _voice_cue("stage10_girl_02")])
                elif stage_number == 11:
                    audio_director.play_voice_sequence([_voice_cue("stage11_girl_01"), _voice_cue("stage11_hero_01"), _voice_cue("stage11_masked_01"), _voice_cue("stage11_girl_02")])
                elif stage_number == 12:
                    audio_director.play_voice_sequence([_voice_cue("stage12_radio_01"), _voice_cue("stage12_hero_01"), _voice_cue("stage12_girl_01"), _voice_cue("stage12_masked_01")])
                else:
                    audio_director.play_voice_sequence(["stage3_girl_01", "stage3_hero_01", "radio_stage3_01"])
            _show_end_card("نجات موفقیت‌آمیز", rescue_dialogue)

func _show_end_card(title_text: String, body_text: String) -> void:
    if is_instance_valid(ending_overlay):
        ending_overlay.queue_free()
    ending_is_victory = title_text == "نجات موفقیت‌آمیز"
    ending_overlay = ColorRect.new()
    ending_overlay.name = "EndCard"
    ending_overlay.color = Color(0.01, 0.012, 0.018, 0.9)
    ending_overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    hud.add_child(ending_overlay)

    ending_title_label = Label.new()
    ending_title_label.text = title_text
    ending_title_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    ending_title_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    ending_title_label.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    ending_title_label.offset_top = -65
    ending_title_label.add_theme_font_size_override("font_size", 38)
    ending_overlay.add_child(ending_title_label)

    ending_body_label = Label.new()
    ending_body_label.text = body_text
    ending_body_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    ending_body_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    ending_body_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    ending_body_label.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    ending_body_label.offset_left = 30.0
    ending_body_label.offset_right = -30.0
    ending_body_label.offset_top = 10
    ending_body_label.add_theme_font_size_override("font_size", 21)
    ending_body_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    ending_body_label.clip_text = false
    ending_overlay.add_child(ending_body_label)

    ending_restart_button = Button.new()
    ending_restart_button.text = "رفتن به مرحلهٔ بعد" if ending_is_victory else "شروع دوباره"
    ending_restart_button.size = Vector2(250, 62)
    ending_restart_button.anchor_left = 0.5
    ending_restart_button.anchor_right = 0.5
    ending_restart_button.anchor_top = 0.72
    ending_restart_button.anchor_bottom = 0.72
    ending_restart_button.offset_left = -125.0
    ending_restart_button.offset_right = 125.0
    ending_restart_button.offset_top = -31.0
    ending_restart_button.offset_bottom = 31.0
    ending_restart_button.add_theme_font_size_override("font_size", 22)
    if ending_is_victory:
        ending_restart_button.pressed.connect(_start_next_stage)
    else:
        ending_restart_button.pressed.connect(func(): get_tree().reload_current_scene())
    ending_overlay.add_child(ending_restart_button)
    _refresh_story_cards()

func _load_saved_stage() -> int:
    var save_data := ConfigFile.new()
    var error := save_data.load("user://last_rescue_progress.cfg")
    if error != OK:
        return 1
    return clampi(int(save_data.get_value("progress", "unlocked_stage", 1)), 1, 999)

func _save_unlocked_stage(unlocked_stage: int) -> void:
    var save_data := ConfigFile.new()
    save_data.load("user://last_rescue_progress.cfg")
    var existing := clampi(int(save_data.get_value("progress", "unlocked_stage", 1)), 1, 999)
    save_data.set_value("progress", "unlocked_stage", maxi(existing, clampi(unlocked_stage, 1, 999)))
    var error := save_data.save("user://last_rescue_progress.cfg")
    if error != OK:
        push_warning("Could not save Last Rescue progress: %s" % error_string(error))

func _start_next_stage() -> void:
    stage_number += 1
    _save_unlocked_stage(stage_number)
    total_zombies = 6 + (stage_number - 1) * 2
    kills = 0
    finished = false
    ended = false
    if is_instance_valid(ending_overlay):
        ending_overlay.queue_free()
        ending_overlay = null
    if is_instance_valid(player):
        player.health = minf(player.max_health, player.health + 25.0)
        player.mobile_move = Vector2.ZERO
        player.set_physics_process(true)
    for enemy in get_tree().get_nodes_in_group("zombies"):
        if is_instance_valid(enemy):
            enemy.queue_free()
    var girl := get_node_or_null("CaptiveGirl")
    if girl:
        girl.position = Vector3(randf_range(-12.0, 12.0), 0.0, randf_range(-18.0, -12.0))
        var beacon := girl.get_node_or_null("RescueBeacon")
        if beacon is OmniLight3D:
            beacon.light_energy = 1.2
    _spawn_zombies()
    update_hud()
    _show_stage_transition_card()

func _show_stage_transition_card() -> void:
    if is_instance_valid(audio_director):
        audio_director.play_voice_sequence(["transition_hero_01", "transition_girl_01", "transition_masked_01"])
    var overlay := ColorRect.new()
    overlay.name = "StageTransitionCard"
    overlay.color = Color(0.01, 0.012, 0.018, 0.92)
    overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    overlay.mouse_filter = Control.MOUSE_FILTER_IGNORE
    hud.add_child(overlay)
    transition_story_label = Label.new()
    transition_story_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    transition_story_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    transition_story_label.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    transition_story_label.offset_left = 30.0
    transition_story_label.offset_right = -30.0
    transition_story_label.add_theme_font_size_override("font_size", 23)
    transition_story_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    transition_story_label.offset_top = 24.0
    transition_story_label.offset_bottom = -24.0
    transition_story_label.add_theme_color_override("font_color", Color(0.78, 0.78, 0.78))
    overlay.add_child(transition_story_label)
    _refresh_story_cards()
    var tween := create_tween()
    tween.tween_interval(2.7)
    tween.tween_property(overlay, "modulate:a", 0.0, 0.7)
    tween.tween_callback(func():
        if is_instance_valid(overlay):
            overlay.queue_free()
        if transition_story_label and not is_instance_valid(transition_story_label):
            transition_story_label = null
    )
