extends CharacterBody3D

@export var move_speed: float = 4.5
@export var acceleration: float = 16.0
@export var gravity: float = 18.0
@export var attack_damage: float = 35.0
@export var attack_range: float = 2.25
@export var attack_arc_dot: float = 0.15
@export var max_health: float = 100.0

var health: float = 100.0
var attack_cooldown: float = 0.0
var mobile_move: Vector2 = Vector2.ZERO
var attack_requested: bool = false
var camera_pivot: Node3D
var camera: Camera3D
var axe_handle: MeshInstance3D
var axe_blade: MeshInstance3D
var main_ref: Node
var attack_tween: Tween
var camera_shake_time: float = 0.0
var camera_home: Vector3 = Vector3.ZERO
# Stage 42: short dodge burst with a cooldown and a brief damage-immunity window.
var dodge_cooldown: float = 0.0
var dodge_timer: float = 0.0
var dodge_invulnerability: float = 0.0
var dodge_direction: Vector3 = Vector3.ZERO
var last_dodge_cooldown_display: int = -1
# Stage 49: native gamepad support (left stick/D-pad, A attack, B dodge).
var gamepad_move: Vector2 = Vector2.ZERO

func _ready() -> void:
    health = max_health
    _build_character()
    _build_camera()
    add_to_group("player")

func _build_character() -> void:
    var capsule := CapsuleMesh.new()
    capsule.radius = 0.38
    capsule.height = 1.8
    var body := MeshInstance3D.new()
    body.name = "HeroBody"
    body.mesh = capsule
    body.position.y = 0.9
    var body_mat := StandardMaterial3D.new()
    body_mat.albedo_color = Color(0.12, 0.16, 0.19)
    body_mat.roughness = 0.9
    body.material_override = body_mat
    add_child(body)

    # Layered survivor gear: shoulder pads and a compact weathered backpack.
    for side in [-1.0, 1.0]:
        var shoulder := MeshInstance3D.new()
        var shoulder_mesh := SphereMesh.new()
        shoulder_mesh.radius = 0.19
        shoulder_mesh.height = 0.22
        shoulder.mesh = shoulder_mesh
        shoulder.position = Vector3(side * 0.31, 1.32, 0.0)
        var shoulder_mat := StandardMaterial3D.new()
        shoulder_mat.albedo_color = Color(0.19, 0.23, 0.24)
        shoulder_mat.roughness = 0.95
        shoulder.material_override = shoulder_mat
        add_child(shoulder)

    var backpack := MeshInstance3D.new()
    var pack_mesh := BoxMesh.new()
    pack_mesh.size = Vector3(0.42, 0.52, 0.2)
    backpack.mesh = pack_mesh
    backpack.position = Vector3(0.0, 1.05, 0.29)
    var pack_mat := StandardMaterial3D.new()
    pack_mat.albedo_color = Color(0.12, 0.19, 0.15)
    pack_mat.roughness = 1.0
    backpack.material_override = pack_mat
    add_child(backpack)

    var head := MeshInstance3D.new()
    var head_mesh := SphereMesh.new()
    head_mesh.radius = 0.23
    head_mesh.height = 0.46
    head.mesh = head_mesh
    head.position = Vector3(0, 1.88, 0)
    var skin := StandardMaterial3D.new()
    skin.albedo_color = Color(0.48, 0.38, 0.31)
    head.material_override = skin
    add_child(head)

    axe_handle = MeshInstance3D.new()
    var handle_mesh := CylinderMesh.new()
    handle_mesh.top_radius = 0.035
    handle_mesh.bottom_radius = 0.035
    handle_mesh.height = 0.8
    axe_handle.mesh = handle_mesh
    axe_handle.position = Vector3(0.43, 1.0, -0.12)
    axe_handle.rotation_degrees.z = -25
    var wood := StandardMaterial3D.new()
    wood.albedo_color = Color(0.22, 0.12, 0.06)
    axe_handle.material_override = wood
    add_child(axe_handle)

    axe_blade = MeshInstance3D.new()
    var blade_mesh := BoxMesh.new()
    blade_mesh.size = Vector3(0.38, 0.18, 0.07)
    axe_blade.mesh = blade_mesh
    axe_blade.position = Vector3(0.43, 1.38, -0.12)
    var metal := StandardMaterial3D.new()
    metal.albedo_color = Color(0.52, 0.56, 0.58)
    metal.metallic = 0.82
    metal.roughness = 0.24
    metal.metallic_specular = 0.9
    axe_blade.material_override = metal
    add_child(axe_blade)

    var collider := CollisionShape3D.new()
    var shape := CapsuleShape3D.new()
    shape.radius = 0.38
    shape.height = 1.8
    collider.shape = shape
    collider.position.y = 0.9
    add_child(collider)

func _build_camera() -> void:
    camera_pivot = Node3D.new()
    camera_pivot.name = "CameraPivot"
    camera_pivot.position = Vector3(0, 1.55, 0)
    add_child(camera_pivot)
    camera = Camera3D.new()
    camera.name = "ThirdPersonCamera"
    camera.position = Vector3(0, 2.1, 6.4)
    camera_home = camera.position
    camera.rotation_degrees.x = -12.0
    camera.current = true
    camera.fov = 72.0
    camera_pivot.add_child(camera)

func _input(event: InputEvent) -> void:
    # Trigger one action per press; held buttons do not auto-repeat.
    if event is InputEventKey and event.pressed and not event.echo:
        if event.keycode == KEY_SPACE:
            request_attack()
        elif event.keycode == KEY_SHIFT:
            request_dodge()
    elif event is InputEventJoypadButton and event.pressed:
        if event.button_index == JOY_BUTTON_A:
            request_attack()
        elif event.button_index == JOY_BUTTON_B:
            request_dodge()

func _read_gamepad_move() -> Vector2:
    var result := Vector2.ZERO
    for device_id in Input.get_connected_joypads():
        var axis := Vector2(
            Input.get_joy_axis(device_id, JOY_AXIS_LEFT_X),
            Input.get_joy_axis(device_id, JOY_AXIS_LEFT_Y)
        )
        if axis.length() < 0.18:
            axis = Vector2.ZERO
        else:
            axis = axis.limit_length(1.0)
        if Input.is_joy_button_pressed(device_id, JOY_BUTTON_DPAD_LEFT):
            axis.x = -1.0
        elif Input.is_joy_button_pressed(device_id, JOY_BUTTON_DPAD_RIGHT):
            axis.x = 1.0
        if Input.is_joy_button_pressed(device_id, JOY_BUTTON_DPAD_UP):
            axis.y = -1.0
        elif Input.is_joy_button_pressed(device_id, JOY_BUTTON_DPAD_DOWN):
            axis.y = 1.0
        if axis.length() >= 0.18:
            result = axis.limit_length(1.0)
            break
    return result

func _physics_process(delta: float) -> void:
    attack_cooldown = maxf(0.0, attack_cooldown - delta)
    dodge_cooldown = maxf(0.0, dodge_cooldown - delta)
    dodge_timer = maxf(0.0, dodge_timer - delta)
    dodge_invulnerability = maxf(0.0, dodge_invulnerability - delta)
    # Refresh HUD only when the visible cooldown number changes.
    var cooldown_display := int(ceil(dodge_cooldown))
    if cooldown_display != last_dodge_cooldown_display:
        last_dodge_cooldown_display = cooldown_display
        if is_instance_valid(main_ref) and main_ref.has_method("update_hud"):
            main_ref.update_hud()
    camera_shake_time = maxf(0.0, camera_shake_time - delta)
    if is_instance_valid(camera):
        var shake := 0.035 if camera_shake_time > 0.0 else 0.0
        camera.position = camera_home + Vector3(randf_range(-shake, shake), randf_range(-shake, shake), 0.0)
    # Read keyboard keys directly so the prototype does not depend on missing InputMap entries.
    var input_vec := Vector2.ZERO
    if Input.is_key_pressed(KEY_A) or Input.is_key_pressed(KEY_LEFT):
        input_vec.x -= 1.0
    if Input.is_key_pressed(KEY_D) or Input.is_key_pressed(KEY_RIGHT):
        input_vec.x += 1.0
    if Input.is_key_pressed(KEY_W) or Input.is_key_pressed(KEY_UP):
        input_vec.y -= 1.0
    if Input.is_key_pressed(KEY_S) or Input.is_key_pressed(KEY_DOWN):
        input_vec.y += 1.0
    gamepad_move = _read_gamepad_move()
    if gamepad_move.length() > 0.1:
        input_vec = gamepad_move
    if mobile_move.length() > 0.1:
        input_vec = mobile_move
    var direction := Vector3(input_vec.x, 0.0, input_vec.y)
    if direction.length() > 1.0:
        direction = direction.normalized()
    if dodge_timer > 0.0:
        velocity.x = dodge_direction.x * 10.5
        velocity.z = dodge_direction.z * 10.5
    else:
        velocity.x = move_toward(velocity.x, direction.x * move_speed, acceleration * delta)
        velocity.z = move_toward(velocity.z, direction.z * move_speed, acceleration * delta)
    if not is_on_floor():
        velocity.y -= gravity * delta
    else:
        velocity.y = 0.0
    if direction.length() > 0.1:
        rotation.y = lerp_angle(rotation.y, atan2(-direction.x, -direction.z), delta * 10.0)
    move_and_slide()
    if attack_requested:
        attack_requested = false
        perform_attack()

func perform_attack() -> void:
    if attack_cooldown > 0.0:
        return
    attack_cooldown = 0.65
    camera_shake_time = 0.10
    if is_instance_valid(main_ref) and main_ref.has_method("play_sfx"):
        main_ref.play_sfx("axe_swing")
    # Stage 14: a restrained FOV punch gives the axe swing more weight; restore even if another swing follows.
    if is_instance_valid(camera):
        var fov_tween := create_tween()
        fov_tween.tween_property(camera, "fov", 68.0, 0.08)
        fov_tween.tween_property(camera, "fov", 72.0, 0.20)
    if is_instance_valid(attack_tween):
        attack_tween.kill()
    axe_handle.rotation_degrees.z = -25.0
    attack_tween = create_tween()
    attack_tween.tween_property(axe_handle, "rotation_degrees:z", -115.0, 0.12)
    attack_tween.tween_property(axe_handle, "rotation_degrees:z", -25.0, 0.2)

    # Only damage a zombie in front of the hero and inside the axe's reach.
    var forward := -global_transform.basis.z
    forward.y = 0.0
    forward = forward.normalized()
    var best: Node3D = null
    var best_distance := attack_range
    for enemy in get_tree().get_nodes_in_group("zombies"):
        if not is_instance_valid(enemy) or not (enemy is Node3D):
            continue
        var offset: Vector3 = enemy.global_position - global_position
        offset.y = 0.0
        var distance := offset.length()
        if distance > 0.05 and distance <= best_distance:
            var dot := forward.dot(offset.normalized())
            if dot >= attack_arc_dot:
                best = enemy
                best_distance = distance
    if best and best.has_method("take_damage"):
        best.take_damage(attack_damage)
        camera_shake_time = 0.14
        if is_instance_valid(main_ref) and main_ref.has_method("play_sfx"):
            main_ref.play_sfx("axe_impact")

func take_damage(amount: float) -> void:
    if dodge_invulnerability > 0.0 or health <= 0.0:
        return
    health = maxf(0.0, health - amount)
    if is_instance_valid(main_ref) and main_ref.has_method("play_sfx"):
        main_ref.play_sfx("hero_hurt")
    if main_ref and main_ref.has_method("update_hud"):
        main_ref.update_hud()
    if health <= 0.0 and main_ref and main_ref.has_method("game_over"):
        main_ref.game_over()

func set_mobile_move(value: Vector2) -> void:
    mobile_move = value

func request_dodge() -> void:
    if health <= 0.0 or dodge_cooldown > 0.0 or dodge_timer > 0.0:
        return
    var input_vec := mobile_move
    if input_vec.length() < 0.1:
        input_vec = _read_gamepad_move()
    if input_vec.length() < 0.1:
        if Input.is_key_pressed(KEY_A) or Input.is_key_pressed(KEY_LEFT):
            input_vec.x -= 1.0
        if Input.is_key_pressed(KEY_D) or Input.is_key_pressed(KEY_RIGHT):
            input_vec.x += 1.0
        if Input.is_key_pressed(KEY_W) or Input.is_key_pressed(KEY_UP):
            input_vec.y -= 1.0
        if Input.is_key_pressed(KEY_S) or Input.is_key_pressed(KEY_DOWN):
            input_vec.y += 1.0
    if input_vec.length() < 0.1:
        input_vec = Vector2(-sin(rotation.y), -cos(rotation.y))
    dodge_direction = Vector3(input_vec.x, 0.0, input_vec.y).normalized()
    dodge_timer = 0.22
    dodge_invulnerability = 0.38
    dodge_cooldown = 2.2
    camera_shake_time = 0.08

func request_attack() -> void:
    if health <= 0.0:
        return
    attack_requested = true
