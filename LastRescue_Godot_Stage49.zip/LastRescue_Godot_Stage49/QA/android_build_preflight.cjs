const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const checks = [
  ['Gradle settings', 'Android_WebView_Wrapper/settings.gradle'],
  ['Gradle app build', 'Android_WebView_Wrapper/app/build.gradle'],
  ['Android manifest', 'Android_WebView_Wrapper/app/src/main/AndroidManifest.xml'],
  ['WebView activity', 'Android_WebView_Wrapper/app/src/main/java/com/lastrescue/game/MainActivity.java'],
  ['Bundled HTML asset', 'Android_WebView_Wrapper/app/src/main/assets/index.html'],
  ['Browser fallback', 'Browser_Fallback/index.html'],
];
let failed = false;
for (const [label, rel] of checks) {
  const full = path.join(root, rel);
  if (!fs.existsSync(full) || !fs.statSync(full).isFile() || fs.statSync(full).size === 0) {
    console.error(`FAIL: ${label} missing/empty: ${rel}`);
    failed = true;
  } else console.log(`PASS: ${label}`);
}
const gradle = fs.readFileSync(path.join(root, 'Android_WebView_Wrapper/app/build.gradle'), 'utf8');
const manifest = fs.readFileSync(path.join(root, 'Android_WebView_Wrapper/app/src/main/AndroidManifest.xml'), 'utf8');
const java = fs.readFileSync(path.join(root, 'Android_WebView_Wrapper/app/src/main/java/com/lastrescue/game/MainActivity.java'), 'utf8');
const browser = fs.readFileSync(path.join(root, 'Browser_Fallback/index.html'), 'utf8');
const bundled = fs.readFileSync(path.join(root, 'Android_WebView_Wrapper/app/src/main/assets/index.html'), 'utf8');
for (const [label, ok] of [
  ['landscape orientation', /screenOrientation="landscape"/.test(manifest)],
  ['APK versionCode 46', /versionCode\s+46/.test(gradle)],
  ['APK versionName 0.46.0', /versionName\s+'0\.46\.0'/.test(gradle)],
  ['offline local asset load', /file:\/\/\/android_asset\/index\.html/.test(java)],
  ['browser/WebView asset parity', browser === bundled],
  ['WebView has JavaScript enabled', /setJavaScriptEnabled\(true\)/.test(java)],
]) {
  if (ok) console.log(`PASS: ${label}`);
  else { console.error(`FAIL: ${label}`); failed = true; }
}
if (failed) process.exit(1);
console.log('PASS: Android WebView build preflight (static checks only; not an APK build)');
