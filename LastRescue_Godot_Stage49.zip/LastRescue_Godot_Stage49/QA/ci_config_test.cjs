const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
const workflow = fs.readFileSync(path.join(root, '.github/workflows/android-apk.yml'), 'utf8');
const gitlab = fs.readFileSync(path.join(root, '.gitlab-ci.yml'), 'utf8');
const gradle = fs.readFileSync(path.join(root, 'Android_WebView_Wrapper/app/build.gradle'), 'utf8');
const preset = fs.readFileSync(path.join(root, 'LastRescue_Godot_Project/export_presets.cfg'), 'utf8');
for (const [label, content] of [['GitHub Actions', workflow], ['GitLab CI', gitlab]]) {
  for (const token of ["versionCode 46", "versionName '0.46.0'", 'version/code=46', 'version/name="0.46.0"']) {
    if (!content.includes(token)) throw new Error(`${label}: missing current version check ${token}`);
  }
}
if (!gradle.includes('versionCode 46') || !gradle.includes("versionName '0.46.0'")) throw new Error('Gradle version does not match 0.46.0 / code 45');
if (!preset.includes('version/code=46') || !preset.includes('version/name="0.46.0"')) throw new Error('Godot export preset does not match 0.46.0 / code 45');
for (const token of ['LastRescue-Godot-3D-APK-v0.46.0', 'LastRescue-WebView-Fallback-APK-v0.46.0']) {
  if (!workflow.includes(token)) throw new Error(`GitHub Actions artifact label missing: ${token}`);
}
if (workflow.includes('versionCode 37') || workflow.includes('0.37.0') || workflow.includes('APK-v0.32.0')) throw new Error('Stale release marker remains in GitHub Actions workflow');
if (!workflow.includes('--headless --editor --path . --quit') || !workflow.includes('--headless --path . --quit-after 45')) throw new Error('Godot import/runtime gates missing');
if (!workflow.includes('unzip -t build/LastRescue-3D-debug.apk') || !workflow.includes('unzip -t app/build/outputs/apk/debug/app-debug.apk')) throw new Error('APK archive integrity checks missing');
console.log('PASS: CI config checks current v0.46.0 release markers, Godot runtime gates, dual APK artifacts, and APK integrity checks');
