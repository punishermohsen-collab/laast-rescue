#!/usr/bin/env sh
set -eu
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
cd "$ROOT"
node QA/ci_config_test.cjs
node QA/stage42_dodge_test.cjs
node QA/stage43_dodge_hud_test.cjs
node QA/stage44_health_bar_test.cjs
node QA/smoke_test.cjs
node QA/smoke_test.cjs
node QA/audio_asset_audit.cjs
node QA/audio_asset_audit.cjs
node QA/resource_path_audit.cjs
node QA/resource_path_audit.cjs
node QA/voice_lab_stage33.cjs
node QA/stage34_intensity_test.cjs
node QA/stage34_intensity_test.cjs
cmp Browser_Fallback/index.html Android_WebView_Wrapper/app/src/main/assets/index.html
grep -q 'versionCode 46' Android_WebView_Wrapper/app/build.gradle
grep -q "versionName '0.46.0'" Android_WebView_Wrapper/app/build.gradle
grep -q 'version/code=46' LastRescue_Godot_Project/export_presets.cfg
grep -q 'version/name="0.46.0"' LastRescue_Godot_Project/export_presets.cfg
printf '%s\n' 'PASS: release Android version markers'
printf '%s\n' 'PASS: double QA and asset parity'

node QA/stage35_neural_tts_test.cjs
node QA/stage36_voice_benchmark_test.cjs
node QA/stage35_neural_tts_test.cjs
node QA/stage36_voice_benchmark_test.cjs

node QA/stage37_voice_setup_test.cjs
node QA/stage37_voice_setup_test.cjs
grep -q 'versionCode 46' Android_WebView_Wrapper/app/build.gradle
grep -q "versionName '0.46.0'" Android_WebView_Wrapper/app/build.gradle
grep -q 'version/code=46' LastRescue_Godot_Project/export_presets.cfg
grep -q 'version/name="0.46.0"' LastRescue_Godot_Project/export_presets.cfg
printf '%s\n' 'PASS: Stage 37 version markers and repeated setup doctor'

node QA/stage38_progress_test.cjs
node QA/stage38_progress_test.cjs
grep -q 'versionCode 46' Android_WebView_Wrapper/app/build.gradle
grep -q "versionName '0.46.0'" Android_WebView_Wrapper/app/build.gradle
grep -q 'version/code=46' LastRescue_Godot_Project/export_presets.cfg
grep -q 'version/name="0.46.0"' LastRescue_Godot_Project/export_presets.cfg
cmp Browser_Fallback/index.html Android_WebView_Wrapper/app/src/main/assets/index.html
printf '%s\n' 'PASS: Stage 38 resume/fresh-start tests and release markers'

node QA/stage39_combat_ai_test.cjs
node QA/stage39_combat_ai_test.cjs
grep -q 'versionCode 46' Android_WebView_Wrapper/app/build.gradle
grep -q "versionName '0.46.0'" Android_WebView_Wrapper/app/build.gradle
grep -q 'version/code=46' LastRescue_Godot_Project/export_presets.cfg
grep -q 'version/name="0.46.0"' LastRescue_Godot_Project/export_presets.cfg
cmp Browser_Fallback/index.html Android_WebView_Wrapper/app/src/main/assets/index.html
printf '%s\n' 'PASS: Stage 39 combat steering tests and release markers'

node QA/stage40_impact_test.cjs
node QA/stage40_impact_test.cjs
grep -q 'versionCode 46' Android_WebView_Wrapper/app/build.gradle
grep -q "versionName '0.46.0'" Android_WebView_Wrapper/app/build.gradle
grep -q 'version/code=46' LastRescue_Godot_Project/export_presets.cfg
grep -q 'version/name="0.46.0"' LastRescue_Godot_Project/export_presets.cfg
cmp Browser_Fallback/index.html Android_WebView_Wrapper/app/src/main/assets/index.html
printf '%s\n' 'PASS: Stage 40 impact and brute slam tests plus release markers'

node QA/stage42_dodge_test.cjs
node QA/stage42_dodge_test.cjs
printf '%s\n' 'PASS: Stage 42 dodge regression and release markers'

node QA/stage43_dodge_hud_test.cjs
node QA/stage44_health_bar_test.cjs
node QA/stage43_dodge_hud_test.cjs
node QA/stage44_health_bar_test.cjs

node QA/stage45_critical_health_test.cjs
node QA/stage45_critical_health_test.cjs
printf '%s\n' 'PASS: Stage 45 critical-health feedback and release markers'

node QA/stage46_damage_flash_test.cjs
node QA/stage46_damage_flash_test.cjs
printf '%s\n' 'PASS: Stage 46 damage-hit feedback and release markers'

node QA/stage47_healing_feedback_test.cjs
node QA/stage47_healing_feedback_test.cjs
printf '%s\n' 'PASS: Stage 47 healing feedback and release markers'
