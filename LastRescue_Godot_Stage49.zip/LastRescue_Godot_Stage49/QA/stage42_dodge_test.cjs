const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
const player = fs.readFileSync(path.join(root, 'LastRescue_Godot_Project/scripts/player.gd'), 'utf8');
const main = fs.readFileSync(path.join(root, 'LastRescue_Godot_Project/scripts/main.gd'), 'utf8');
const gradle = fs.readFileSync(path.join(root, 'Android_WebView_Wrapper/app/build.gradle'), 'utf8');
const preset = fs.readFileSync(path.join(root, 'LastRescue_Godot_Project/export_presets.cfg'), 'utf8');
for (const token of ['var dodge_cooldown: float = 0.0', 'var dodge_invulnerability: float = 0.0', 'func request_dodge() -> void:', 'dodge_timer = 0.22', 'dodge_invulnerability = 0.38', 'dodge_cooldown = 2.2', 'if dodge_invulnerability > 0.0 or health <= 0.0']) {
  if (!player.includes(token)) throw new Error(`Stage 42 dodge feature missing: ${token}`);
}
for (const token of ['func _on_dodge_pressed() -> void:', 'dodge_button.pressed.connect(_on_dodge_pressed)', 'dodge_button.text = "Dodge"']) {
  if (!main.includes(token)) throw new Error(`Stage 42 dodge control missing: ${token}`);
}
if (!player.includes('event.keycode == KEY_SHIFT')) throw new Error('Stage 42 keyboard dodge binding missing');
if (!gradle.includes('versionCode 46') || !gradle.includes("versionName '0.46.0'") || !preset.includes('version/code=46') || !preset.includes('version/name="0.46.0"')) throw new Error('Stage 42 release markers mismatch');
console.log('PASS: Stage 42 dodge burst, 0.38s immunity, 2.2s cooldown, keyboard/mobile controls, release markers');
