const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
const player = fs.readFileSync(path.join(root, 'LastRescue_Godot_Project/scripts/player.gd'), 'utf8');
const main = fs.readFileSync(path.join(root, 'LastRescue_Godot_Project/scripts/main.gd'), 'utf8');
for (const token of ['var last_dodge_cooldown_display: int = -1', 'var cooldown_display := int(ceil(dodge_cooldown))', 'if cooldown_display != last_dodge_cooldown_display', 'main_ref.update_hud()']) {
  if (!player.includes(token)) throw new Error(`Stage 43 cooldown refresh missing: ${token}`);
}
for (const token of ['var dodge_ready := player.dodge_cooldown <= 0.0 and player.health > 0.0', 'dodge_button.disabled = not dodge_ready', 'Dodge: Ready', 'جاخالی: آماده']) {
  if (!main.includes(token)) throw new Error(`Stage 43 cooldown HUD missing: ${token}`);
}
console.log('PASS: Stage 43 localized dodge cooldown status, disabled-until-ready mobile button, event-based HUD refresh');
