const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
const main = fs.readFileSync(path.join(root, 'LastRescue_Godot_Project/scripts/main.gd'), 'utf8');
const gradle = fs.readFileSync(path.join(root, 'Android_WebView_Wrapper/app/build.gradle'), 'utf8');
const preset = fs.readFileSync(path.join(root, 'LastRescue_Godot_Project/export_presets.cfg'), 'utf8');
for (const token of ['var health_bar: ProgressBar', 'health_bar = ProgressBar.new()', 'health_bar.max_value = player.max_health', 'health_bar.value = player.health', 'var health_ratio := clampf(player.health / maxf(1.0, player.max_health), 0.0, 1.0)', 'health_fill.bg_color = Color(0.90, 0.18, 0.14, 1.0).lerp(Color(0.18, 0.78, 0.32, 1.0), health_ratio)', 'سلامتی: %d از %d']) {
  if (!main.includes(token)) throw new Error(`Stage 44 health HUD missing: ${token}`);
}
if (!gradle.includes('versionCode 46') || !gradle.includes("versionName '0.46.0'") || !preset.includes('version/code=46') || !preset.includes('version/name="0.46.0"')) throw new Error('Stage 44 release markers mismatch');
console.log('PASS: Stage 44 health bar follows player health, localized health totals, low-health color feedback, release markers');
