const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
const main = fs.readFileSync(path.join(root, 'LastRescue_Godot_Project/scripts/main.gd'), 'utf8');
const browser = fs.readFileSync(path.join(root, 'Browser_Fallback/index.html'), 'utf8');
const webview = fs.readFileSync(path.join(root, 'Android_WebView_Wrapper/app/src/main/assets/index.html'), 'utf8');
const gradle = fs.readFileSync(path.join(root, 'Android_WebView_Wrapper/app/build.gradle'), 'utf8');
const preset = fs.readFileSync(path.join(root, 'LastRescue_Godot_Project/export_presets.cfg'), 'utf8');
for (const token of ['DamageHitFlash', 'damage_flash_timer = 0.24', 'player.health < last_observed_health', 'mouse_filter = Control.MOUSE_FILTER_IGNORE']) {
  if (!main.includes(token)) throw new Error(`Godot damage feedback missing: ${token}`);
}
for (const token of ['damageFlash', "if(damageFlash>0)", "damageFlash=.22"]) {
  if (!browser.includes(token)) throw new Error(`Browser damage feedback missing: ${token}`);
}
if (browser !== webview) throw new Error('Browser fallback and Android WebView asset diverged');
if (!gradle.includes('versionCode 46') || !gradle.includes("versionName '0.46.0'") || !preset.includes('version/code=46') || !preset.includes('version/name="0.46.0"')) throw new Error('Stage 46 release markers mismatch');
console.log('PASS: Stage 46 damage-hit flash, browser/WebView parity, release markers');
