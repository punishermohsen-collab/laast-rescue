const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
const main = fs.readFileSync(path.join(root, 'LastRescue_Godot_Project/scripts/main.gd'), 'utf8');
const browser = fs.readFileSync(path.join(root, 'Browser_Fallback/index.html'), 'utf8');
const webview = fs.readFileSync(path.join(root, 'Android_WebView_Wrapper/app/src/main/assets/index.html'), 'utf8');
const gradle = fs.readFileSync(path.join(root, 'Android_WebView_Wrapper/app/build.gradle'), 'utf8');
const preset = fs.readFileSync(path.join(root, 'LastRescue_Godot_Project/export_presets.cfg'), 'utf8');
for (const token of ['HealingFeedback', 'healing_feedback_timer = 1.35', 'player.health > last_observed_health', '+%d سلامتی بازیابی شد', '+%d HP RESTORED']) {
  if (!main.includes(token)) throw new Error(`Godot healing feedback missing: ${token}`);
}
for (const token of ['healingFeedback', 'healingFeedbackTimer=1.35', 'healingFeedbackAmount=Math.round(health-beforeHealth)', '+${healingFeedbackAmount} HP RESTORED', '+${healingFeedbackAmount} سلامتی بازیابی شد']) {
  if (!browser.includes(token)) throw new Error(`Browser healing feedback missing: ${token}`);
}
if (browser !== webview) throw new Error('Browser fallback and Android WebView asset diverged');
if (!gradle.includes('versionCode 46') || !gradle.includes("versionName '0.46.0'") || !preset.includes('version/code=46') || !preset.includes('version/name="0.46.0"')) throw new Error('Stage 47 release markers mismatch');
console.log('PASS: Stage 47 bilingual exact healing feedback, timeout/fade, browser-WebView parity, release markers');
