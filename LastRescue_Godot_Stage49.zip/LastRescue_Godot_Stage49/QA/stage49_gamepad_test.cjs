const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
const player = fs.readFileSync(path.join(root, 'LastRescue_Godot_Project/scripts/player.gd'), 'utf8');
const browser = fs.readFileSync(path.join(root, 'Browser_Fallback/index.html'), 'utf8');
const webview = fs.readFileSync(path.join(root, 'Android_WebView_Wrapper/app/src/main/assets/index.html'), 'utf8');
const gradle = fs.readFileSync(path.join(root, 'Android_WebView_Wrapper/app/build.gradle'), 'utf8');
const preset = fs.readFileSync(path.join(root, 'LastRescue_Godot_Project/export_presets.cfg'), 'utf8');
for (const token of ['InputEventJoypadButton', 'JOY_BUTTON_A', 'JOY_BUTTON_B', 'JOY_AXIS_LEFT_X', 'JOY_AXIS_LEFT_Y', 'JOY_BUTTON_DPAD_LEFT', 'JOY_BUTTON_DPAD_RIGHT', '_read_gamepad_move', '0.18']) {
  if (!player.includes(token)) throw new Error(`Godot gamepad support missing: ${token}`);
}
for (const token of ['navigator.getGamepads', 'gamepadMove', 'gamepadAttackWasDown', 'gamepadDodgeWasDown', 'down(14)', 'down(15)', 'down(12)', 'down(13)', 'if(attackDown&&!gamepadAttackWasDown)attack()', 'if(dodgeDown&&!gamepadDodgeWasDown)dodge()']) {
  if (!browser.includes(token)) throw new Error(`Browser/WebView gamepad support missing: ${token}`);
}
if (browser !== webview) throw new Error('Browser fallback and Android WebView asset diverged');
if (!gradle.includes('versionCode 46') || !gradle.includes("versionName '0.46.0'")) throw new Error('Android release version is not 0.46.0 / code 46');
if (!preset.includes('version/code=46') || !preset.includes('version/name="0.46.0"')) throw new Error('Godot export version is not 0.46.0 / code 46');
console.log('PASS: Stage 49 gamepad mapping (left stick/D-pad, A attack, B dodge), deadzone, edge-trigger protection, WebView parity, and v0.46.0 markers');
console.log('LIMIT: no physical controller or Godot runtime is available here; hardware/game-engine behavior remains unverified.');
